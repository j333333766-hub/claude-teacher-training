# 엣지 IE 모드와 관련된 창을 나열한다: 문서 창(Internet Explorer_Server), 웹 페이지 대화 상자, 메시지 상자(#32770).
# 출력의 맨 앞 숫자가 iedom.ps1 / ieclick.ps1 의 -Hwnd 값이다.
Add-Type @'
using System; using System.Text; using System.Runtime.InteropServices; using System.Collections.Generic;
public class IeWin { public delegate bool P(IntPtr h, IntPtr l);
[DllImport("user32.dll")] public static extern bool EnumWindows(P p, IntPtr l);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h, P p, IntPtr l);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
public struct RECT { public int L,T,R,B; }
static string T(IntPtr h){ var t=new StringBuilder(512); GetWindowText(h,t,512); return t.ToString(); }
static string C(IntPtr h){ var t=new StringBuilder(256); GetClassName(h,t,256); return t.ToString(); }
public static List<string> L(){ var r=new List<string>(); var seen=new HashSet<long>();
  P scan=null; scan=(h,l)=>{ if(!seen.Add(h.ToInt64())) return true; string c=C(h);
    if(c=="Internet Explorer_Server" && IsWindowVisible(h)){ RECT rc; GetWindowRect(h,out rc); if(rc.R-rc.L>300) r.Add(h.ToInt64()+" | 문서 | "+rc.L+","+rc.T+","+rc.R+","+rc.B); }
    EnumChildWindows(h,scan,IntPtr.Zero); return true; };
  EnumWindows((h,l)=>{ string c=C(h); if(IsWindowVisible(h)){
      if(c=="#32770"){ var x=new List<string>(); EnumChildWindows(h,(k,l2)=>{ string t=T(k); if(t.Length>0) x.Add(t.Replace("\r\n"," ").Replace("\n"," ")); return true;},IntPtr.Zero); if(T(h)!="BODA_AGENT") r.Add(h.ToInt64()+" | 메시지 상자 ["+T(h)+"] | "+string.Join(" / ",x)); }
      else if(c.Contains("TridentDlg")) r.Add(h.ToInt64()+" | 대화 상자 틀 | "+T(h));
      else if(c=="TabWindowClass"||T(h).Contains("Edge")) r.Add(h.ToInt64()+" | "+c+" | "+T(h)); }
    scan(h,IntPtr.Zero); return true; }, IntPtr.Zero);
  return r; } }
'@
[IeWin]::L()
