# 기안 본문(HWP 컨트롤)의 누름틀 이름과 값을 UTF-8 파일로 뽑는다. 결재제목·본문·수신 등.
#   pwsh -File hwpfields.ps1 -Hwnd <문서 창 핸들> -Out fields.txt
param([long]$Hwnd,[string]$Out,[string]$Frame='editor1')
. "$PSScriptRoot\lib.ps1"
$h=Get-Hwp $Hwnd $Frame
$names=(Inv $h 'GetFieldList' @(0,0)) -split [char]2
$o=""; foreach($fn in $names){ $o += "[$fn] = " + (Inv $h 'GetFieldText' @($fn)) + "`n" }
[IO.File]::WriteAllText($Out,$o,[Text.Encoding]::UTF8); "saved $Out ($($names.Count) fields)"
