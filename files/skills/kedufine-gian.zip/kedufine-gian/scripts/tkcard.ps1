# 과제카드선택 창(nexacro)에서 카드 목록을 보거나, 이름 일부가 맞는 카드를 골라 '확인'까지 누른다.
#   목록:  pwsh -File tkcard.ps1 -Dlg <과제카드 창 핸들> -List -Out cards.txt
#   선택:  pwsh -File tkcard.ps1 -Dlg <과제카드 창 핸들> -Match "교육공무원인사발령관리"
# 과제카드 창은 기안 창에서 aChooseTkcrd 를 누르면 뜬다(iego.ps1 -Id aChooseTkcrd). 창 핸들은 iewin.ps1 의 '문서 | 575,282,...' 처럼
# 작은 크기로 나오는 줄이다. 목록은 '나의과제카드함'에 있는 카드만 나온다(검색도 그 안에서만 됨).
param([long]$Dlg,[switch]$List,[string]$Match,[string]$Out)
$js = Join-Path $env:TEMP 'tkcard.js'; $res = Join-Path $env:TEMP 'tkcard.out.txt'
if($List){
  $code=@'
var ds=nexacro.getApplication().mainframe.frame.form.dsAList; var o=[];
for(var r=0;r<ds.getRowCount();r++) o.push(r+': '+ds.getColumn(r,'tkcrdNm')+' ('+ds.getColumn(r,'dcryPrsrvPdSeNm')+')');
return o.join('\n');
'@
  [IO.File]::WriteAllText($js,$code,[Text.Encoding]::UTF8)
  powershell -NoProfile -File "$PSScriptRoot\iejs.ps1" -Hwnd $Dlg -File $js -Out $(if($Out){$Out}else{$res}) | Out-Null
  if(-not $Out){ Get-Content $res -Encoding UTF8 }; return
}
$m = $Match -replace "'","\'"
$code=@"
var F=nexacro.getApplication().mainframe.frame.form; var ds=F.dsAList; var hit=-1;
for(var r=0;r<ds.getRowCount();r++){ if(String(ds.getColumn(r,'tkcrdNm')).indexOf('$m')>=0){ hit=r; break; } }
if(hit<0) return 'NOTFOUND';
ds.setColumn(hit,'chk','1'); ds.set_rowposition(hit);
var f=F.Tab00.tabpages[0].form; setTimeout(function(){ f.divAuth.form.btnAuthC01.click(); },300);
return 'OK '+ds.getColumn(hit,'tkcrdNm')+' ('+ds.getColumn(hit,'dcryPrsrvPdSeNm')+')';
"@
[IO.File]::WriteAllText($js,$code,[Text.Encoding]::UTF8)
powershell -NoProfile -File "$PSScriptRoot\iejs.ps1" -Hwnd $Dlg -File $js -Out $res 2>$null | Out-Null
Get-Content $res -Encoding UTF8 -ErrorAction SilentlyContinue
"(확인을 누르면 창이 닫혀 결과 읽기에서 오류가 날 수 있다. 기안 창을 캡처해 과제카드 칸을 확인할 것)"
