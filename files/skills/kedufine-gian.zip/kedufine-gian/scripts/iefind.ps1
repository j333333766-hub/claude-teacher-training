# 열려 있는 엣지 IE 모드 문서 창을 모두 찾아 핸들·주소·제목칸(Sj) 값을 보여 준다. 숨은 탭도 나온다(vis=False).
#   powershell -File iefind.ps1        (Windows PowerShell 5.1로 실행해야 Sj 값이 읽힌다)
# 기안 작성 창은 url에 retrieveDoccrdWritng.do 가 들어 있다. REDRAFTAT=TRUE 면 재기안.
. "$PSScriptRoot\lib.ps1"
Add-Type @'
using System; using System.Text; using System.Runtime.InteropServices; using System.Collections.Generic;
public class AW { public delegate bool P(IntPtr h, IntPtr l);
[DllImport("user32.dll")] public static extern bool EnumWindows(P p, IntPtr l);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h, P p, IntPtr l);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
public static List<long> L(){ var r=new List<long>(); EnumWindows((h,l)=>{ EnumChildWindows(h,(k,l2)=>{ var s=new StringBuilder(64); GetClassName(k,s,64); if(s.ToString()=="Internet Explorer_Server") r.Add(k.ToInt64()); return true;},IntPtr.Zero); return true;},IntPtr.Zero); return r; } }
'@
foreach($h in [AW]::L()){ try{ $d=[IeDom]::Get([IntPtr]$h); if(-not $d){ continue }; $u=[string]$d.URL; if($u -eq 'about:blank'){ continue }
  $sj=$d.getElementById('Sj'); $t= if($sj){$sj.value}else{''}
  "$h vis=$([AW]::IsWindowVisible([IntPtr]$h)) sj=$t url=$($u.Substring(0,[Math]::Min(100,$u.Length)))" }catch{} }
