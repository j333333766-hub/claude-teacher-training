# 창 하나를 PrintWindow로 캡처한다. 다른 창에 가려져 있어도 찍힌다(엣지 IE 모드 문서 창 등).
# 단, WebView2 앱(ICE-TALK)은 옛 화면이 찍힐 수 있으니 screen.ps1 로 화면을 찍는다.
#   pwsh -File wincap.ps1 -Hwnd <핸들> -Out shot.png
param([long]$Hwnd,[string]$Out)
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;using System.Runtime.InteropServices;
public class PW{[DllImport("user32.dll")]public static extern bool PrintWindow(IntPtr h,IntPtr dc,uint f);
[DllImport("user32.dll")]public static extern bool GetWindowRect(IntPtr h,out R r);public struct R{public int L,T,Rr,B;}}
"@
$r=New-Object PW+R; [PW]::GetWindowRect([IntPtr]$Hwnd,[ref]$r)|Out-Null
if($r.Rr -le $r.L){ "창이 없거나 크기가 0"; exit 1 }
$b=New-Object System.Drawing.Bitmap ($r.Rr-$r.L),($r.B-$r.T); $g=[System.Drawing.Graphics]::FromImage($b); $dc=$g.GetHdc()
[PW]::PrintWindow([IntPtr]$Hwnd,$dc,2)|Out-Null; $g.ReleaseHdc($dc); $b.Save($Out); "saved $Out"
