# 방금 연 결재 문서 창(4,... 로 시작하는 큰 '문서')을 찾아 캡처한다. 출력: 핸들
param([string]$Out)
Start-Sleep 3
$w = & "$HOME\.claude\skills\kedufine-gian\scripts\iewin.ps1"
$w | Where-Object { $_ -match 'Edge' } | Select-Object -First 1
$h = ($w | Where-Object { $_ -match '^\d+ \| 문서 \| 4,' } | Select-Object -First 1) -replace ' \|.*', ''
"HWND=$h"
if ($h) { pwsh -NoProfile -File "$HOME\.claude\skills\kedufine-gian\scripts\wincap.ps1" -Hwnd $h -Out $Out | Out-Null }
