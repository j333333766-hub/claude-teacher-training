# IE 모드 창(문서 또는 nexacro 대화 상자)에서 페이지 JavaScript를 실행하고 결과를 UTF-8 파일로 받는다.
#   powershell -File iejs.ps1 -Hwnd <핸들> -File code.js [-Out result.txt]
# 반드시 Windows PowerShell 5.1(powershell.exe)로 실행한다. pwsh 7은 documentElement 등이 null 이 된다. execScript 는 없다.
# code.js 는 함수 본문이다: 마지막에 return 으로 문자열을 돌려준다. 모달을 띄우는 호출(확인 버튼, 파일 대화 상자)은
# setTimeout(function(){...},100) 으로 감싸야 이 스크립트가 돌아온다.
param([long]$Hwnd,[string]$File,[string]$Code,[string]$Out)
. "$PSScriptRoot\lib.ps1"
$doc=[IeDom]::Get([IntPtr]$Hwnd)
if(-not $doc){ "문서 객체를 얻지 못함"; exit 1 }
if($File){ $Code=[IO.File]::ReadAllText($File,[Text.Encoding]::UTF8) }
$wrapped = "try{ document.documentElement.setAttribute('data-cc', String((function(){ $Code })())); }catch(e){ document.documentElement.setAttribute('data-cc','ERR '+e.message); }"
$s=$doc.createElement('script'); $s.text=$wrapped
$doc.getElementsByTagName('head').item(0).appendChild($s) | Out-Null
$r=[string]$doc.documentElement.getAttribute('data-cc')
if($Out){ [IO.File]::WriteAllText($Out,$r,[Text.Encoding]::UTF8); "saved $Out" } else { $r }
