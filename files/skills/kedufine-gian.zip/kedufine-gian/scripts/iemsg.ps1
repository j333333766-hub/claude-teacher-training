# IE 모드가 띄운 메시지 상자(#32770)를 나열하거나, 본문에 -Must 문구가 있는 상자에서 -Button 으로 시작하는 버튼을 누른다.
#   나열: pwsh -File iemsg.ps1
#   누름: pwsh -File iemsg.ps1 -Must "결재하시겠습니까" -Button "확인"
# 문구가 다르면 누르지 않는다. 되돌릴 수 없는 확인을 엉뚱한 상자에서 누르지 않기 위해서다.
param([string]$Must, [string]$Button = '확인')
Add-Type @'
using System; using System.Text; using System.Runtime.InteropServices; using System.Collections.Generic;
public class IeMsg { public delegate bool P(IntPtr h, IntPtr l);
[DllImport("user32.dll")] public static extern bool EnumWindows(P p, IntPtr l);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h, P p, IntPtr l);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int InternalGetWindowText(IntPtr h, StringBuilder s, int n);
[DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
static string T(IntPtr h){ var t=new StringBuilder(1024); InternalGetWindowText(h,t,1024); return t.ToString(); }
static string C(IntPtr h){ var t=new StringBuilder(256); GetClassName(h,t,256); return t.ToString(); }
public static List<string> Run(string must, string button){ var r=new List<string>();
  EnumWindows((h,l)=>{ if(!IsWindowVisible(h)||C(h)!="#32770"||T(h)=="BODA_AGENT") return true;
    var texts=new List<string>(); IntPtr b=IntPtr.Zero;
    EnumChildWindows(h,(c,l2)=>{ string t=T(c); if(t.Length>0) texts.Add(t.Replace("\r\n"," ").Replace("\n"," ")); if(C(c)=="Button"&&t.Replace("&","").StartsWith(button)) b=c; return true;},IntPtr.Zero);
    string all=string.Join(" / ",texts);
    if(string.IsNullOrEmpty(must)) r.Add("["+T(h)+"] "+all);
    else if(all.Contains(must)&&b!=IntPtr.Zero){ PostMessage(b,0x00F5,IntPtr.Zero,IntPtr.Zero); r.Add("누름 '"+T(b)+"': ["+T(h)+"] "+all); }
    return true;},IntPtr.Zero);
  if(r.Count==0) r.Add(string.IsNullOrEmpty(must)?"메시지 상자 없음":"'"+must+"' 문구의 메시지 상자를 찾지 못해 누르지 않음");
  return r; } }
'@
[IeMsg]::Run($Must, $Button)
