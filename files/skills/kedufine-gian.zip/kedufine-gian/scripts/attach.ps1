# 기안 창의 첨부파일을 다룬다.
#   목록:      pwsh -File attach.ps1 -Hwnd <문서 창 핸들> -List
#   전부 삭제: pwsh -File attach.ps1 -Hwnd <문서 창 핸들> -Clear     (재기안 때 따라온 옛 첨부 지우기)
#   추가 창:   pwsh -File attach.ps1 -Hwnd <문서 창 핸들> -Add       (파일 '열기' 대화 상자를 띄운다 → filedlg.ps1 -Open)
# 허용 확장자에 HWPX·HWP·PDF 등이 있다. 파일명 70자 초과·크기 0은 거부된다.
param([long]$Hwnd,[switch]$List,[switch]$Clear,[switch]$Add)
$js = Join-Path $env:TEMP 'attach.js'; $res = Join-Path $env:TEMP 'attach.out.txt'
if($List){ $code="var f=Attach.fileBox._files||[]; var o=[]; for(var i=0;i<f.length;i++) o.push(f[i].name+' ('+f[i].size+')'); return 'count='+f.length+'\n'+o.join('\n');" }
elseif($Clear){ $code=@'
var box=document.getElementById('HSFileBox'); var cbs=box.getElementsByTagName('input');
for(var i=0;i<cbs.length;i++){ var c=cbs[i]; if(c.type=='checkbox' && c.className!='checkall' && !c.checked){ c.click(); } }
var n=Attach.fileBox.selectedFiles().length; if(n>0) fncDeleteFile();
return 'deleted='+n+' left='+Attach.fileBox.files().length;
'@ }
elseif($Add){ $code="setTimeout(function(){ fncFileAdit(); },100); return 'opening file dialog';" }
else { "-List / -Clear / -Add 중 하나"; exit 1 }
[IO.File]::WriteAllText($js,$code,[Text.Encoding]::UTF8)
powershell -NoProfile -File "$PSScriptRoot\iejs.ps1" -Hwnd $Hwnd -File $js -Out $res | Out-Null
Get-Content $res -Encoding UTF8
