# IE 모드 탭 문서에서 id로 지정한 요소를 누른다. 제목(-Expect)이 맞을 때만 누른다.
# 누른 뒤 확인 창(모달)이 뜨면 이 호출은 창이 닫힐 때까지 돌아오지 않으므로, 부르는 쪽에서 시간 제한을 두고 실행한다.
param([long]$Hwnd, [string]$Id, [string]$Expect, [string]$Text)

Add-Type @'
using System; using System.Runtime.InteropServices;
public class IeDom {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  [DllImport("oleacc.dll", PreserveSig=false)] [return: MarshalAs(UnmanagedType.IDispatch)]
  public static extern object ObjectFromLresult(IntPtr lResult, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, IntPtr wParam);
  public static object Get(IntPtr h) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT");
    IntPtr res; SendMessageTimeout(h, msg, IntPtr.Zero, IntPtr.Zero, 2, 3000, out res);
    if (res == IntPtr.Zero) return null;
    return ObjectFromLresult(res, new Guid("626FC520-A41E-11CF-A731-00A0C9082637"), IntPtr.Zero);
  }
}
'@

$doc = [IeDom]::Get([IntPtr]$Hwnd)
if (-not $doc) { "문서 객체를 얻지 못함"; exit 1 }
$sj = $doc.getElementById('Sj')
$title = if ($sj -and $sj -isnot [DBNull]) { [string]$sj.value } else { '' }
"문서 제목: $title"
if ($Expect -and $title -notlike "*$Expect*") { "제목이 '$Expect' 와 달라 누르지 않음"; exit 2 }
if ($Text) {
  # id가 없는 요소는 -Text 로 찾는다: 보이는 a·button·img 중 글자(또는 alt)가 정확히 같은 첫 번째
  $e = $null
  foreach ($tag in 'a','button','img','input') {
    $els = $doc.getElementsByTagName($tag)
    for ($i = 0; $i -lt $els.length -and -not $e; $i++) {
      $c = $els.item($i); $t = ([string]$c.innerText).Trim(); if (-not $t) { $t = [string]$c.alt }; if (-not $t) { $t = [string]$c.value }
      if ($t -eq $Text -and $c.offsetWidth -gt 0) { $e = $c }
    }
    if ($e) { break }
  }
  $Id = "글자 '$Text'"
} else { $e = $doc.getElementById($Id) }
if (-not $e -or $e -is [DBNull]) { "$Id 요소 없음"; exit 3 }
if ($e.offsetWidth -eq 0) { "$Id 요소가 화면에 보이지 않아 누르지 않음"; exit 4 }
"누름: $Id '$(([string]$e.innerText).Trim())'"
$e.click()
"click 반환됨"
