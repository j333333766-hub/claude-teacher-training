# 기안 제목과 본문을 넣는다. 카드의 제목칸(Sj)과 본문 누름틀 '결재제목'을 같이 바꾸고, '본문' 누름틀을 통째로 바꾼다.
#   pwsh -File hwpput.ps1 -Hwnd <문서 창 핸들> -Title "제목" -BodyFile body.txt
# body.txt 는 UTF-8. 들여쓰기는 공백 2칸(가.), 4칸(1)). 붙임 줄 끝에 '  끝.'
# 넣은 뒤 wincap.ps1 로 캡처해 '끝.'이 줄바꿈되지 않았는지, 1쪽에 들어가는지 확인한다.
param([long]$Hwnd,[string]$Title,[string]$BodyFile)
. "$PSScriptRoot\lib.ps1"
$doc=[IeDom]::Get([IntPtr]$Hwnd)
$h=$doc.getElementById('editor1').contentWindow.document.getElementById('editor1')
if($Title){ Inv $h 'PutFieldText' @('결재제목',$Title) | Out-Null; $doc.getElementById('Sj').value=$Title }
if($BodyFile){ $body=([IO.File]::ReadAllText($BodyFile,[Text.Encoding]::UTF8)).TrimEnd() -replace "`r?`n","`r`n"; Inv $h 'PutFieldText' @('본문',$body) | Out-Null }
"제목칸=" + $doc.getElementById('Sj').value
