# 화면 캡처와 좌표 클릭. 엣지 IE 모드 탭처럼 브라우저 확장으로 조작할 수 없는 화면에 쓴다.
#   캡처만:       pwsh -File screen.ps1 -Out shot.png [-X 0 -Y 0 -W 1920 -H 1080]
#   클릭 후 캡처: pwsh -File screen.ps1 -Click 553,236 -Out shot.png
#   창 목록:      pwsh -File screen.ps1 -Windows        (화면 전체 크기와 엣지 창의 제목·위치)
# 캡처 이미지의 (x,y)는 화면 좌표 (X+x, Y+y)다. 가로 1920px 이하로 잘라서 읽어야 축소 없이 좌표가 맞는다.
param([int[]]$Click,[string]$Out,[int]$X=0,[int]$Y=0,[int]$W=1920,[int]$H=1080,[switch]$Windows)
Add-Type -AssemblyName System.Windows.Forms, System.Drawing, UIAutomationClient, UIAutomationTypes
Add-Type @"
using System;using System.Runtime.InteropServices;
public class Scr{[DllImport("user32.dll")]public static extern bool SetCursorPos(int x,int y);
[DllImport("user32.dll")]public static extern void mouse_event(uint f,uint dx,uint dy,uint d,UIntPtr e);}
"@
if($Windows){
  $v=[System.Windows.Forms.SystemInformation]::VirtualScreen; "화면 전체: $($v.X),$($v.Y) $($v.Width)x$($v.Height)"
  $A=[System.Windows.Automation.AutomationElement]
  $c=New-Object System.Windows.Automation.PropertyCondition($A::ClassNameProperty,'Chrome_WidgetWin_1')
  foreach($e in $A::RootElement.FindAll([System.Windows.Automation.TreeScope]::Children,$c)){ if($e.Current.Name -match 'Edge'){ $r=$e.Current.BoundingRectangle; "엣지 창: $([int]$r.X),$([int]$r.Y) $([int]$r.Width)x$([int]$r.Height)  $($e.Current.Name)" } }
  return
}
if($Click){ [Scr]::SetCursorPos($Click[0],$Click[1])|Out-Null; Start-Sleep -Milliseconds 200; [Scr]::mouse_event(2,0,0,0,[UIntPtr]::Zero); [Scr]::mouse_event(4,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 1500 }
if($Out){ $b=New-Object System.Drawing.Bitmap $W,$H; $g=[System.Drawing.Graphics]::FromImage($b); $g.CopyFromScreen($X,$Y,0,0,$b.Size); $b.Save($Out); $g.Dispose(); $b.Dispose(); "saved $Out (화면 $X,$Y 부터 ${W}x$H)" }
