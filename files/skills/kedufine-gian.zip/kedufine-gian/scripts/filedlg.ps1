# Windows '열기' 파일 대화 상자(#32770)에 폴더와 파일 이름을 넣고(선택) 열기를 누른다. 마우스·키보드를 쓰지 않는다.
#   pwsh -File filedlg.ps1 -Dlg <대화상자 핸들> -Folder "C:\폴더" -Names "a.hwpx|b.hwpx" [-Open]
# 대화 상자 핸들은 iewin.ps1 출력의 '메시지 상자 [열기]' 줄 맨 앞 숫자다.
# 파일 이름이 여러 개면 | 로 나눈다. -Open 을 주면 이름을 넣은 뒤 '열기'(IDOK)까지 보낸다.
param([long]$Dlg,[string]$Folder,[string]$Names,[switch]$Open)
Add-Type @"
using System;using System.Text;using System.Runtime.InteropServices;
public class FD{public delegate bool P(IntPtr h,IntPtr l);
[DllImport("user32.dll")]public static extern bool EnumChildWindows(IntPtr h,P p,IntPtr l);
[DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern int GetClassName(IntPtr h,StringBuilder s,int n);
[DllImport("user32.dll",CharSet=CharSet.Unicode)]public static extern IntPtr SendMessage(IntPtr h,uint m,IntPtr w,string l);
[DllImport("user32.dll")]public static extern IntPtr SendMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
[DllImport("user32.dll")]public static extern IntPtr PostMessage(IntPtr h,uint m,IntPtr w,IntPtr l);
[DllImport("user32.dll")]public static extern int GetDlgCtrlID(IntPtr h);
[DllImport("user32.dll")]public static extern IntPtr GetParent(IntPtr h);
public static IntPtr FileEdit(IntPtr dlg){ IntPtr r=IntPtr.Zero; EnumChildWindows(dlg,(h,l)=>{var s=new StringBuilder(64);GetClassName(h,s,64); if(s.ToString()=="Edit"){ var p=GetParent(h); var ps=new StringBuilder(64); GetClassName(p,ps,64); if(ps.ToString()=="ComboBox" && GetDlgCtrlID(GetParent(p))==0x47C){ r=h; return false;} } return true;},IntPtr.Zero); return r;}}
"@
$d=[IntPtr]$Dlg; $e=[FD]::FileEdit($d)
if($e -eq [IntPtr]::Zero){ "파일 이름 칸을 찾지 못함(열기 대화 상자가 맞는지 확인)"; exit 1 }
$WM_SETTEXT=0x000C; $WM_COMMAND=0x0111
if($Folder){
  [FD]::SendMessage($e,$WM_SETTEXT,[IntPtr]::Zero,$Folder)|Out-Null
  [FD]::SendMessage($d,$WM_COMMAND,[IntPtr]1,[IntPtr]::Zero)|Out-Null   # 폴더로 이동
  Start-Sleep -Seconds 2
  $e=[FD]::FileEdit($d)
}
$list = $Names -split '\|' | Where-Object { $_ }
$txt = if($list.Count -gt 1){ ($list | ForEach-Object { '"' + $_ + '"' }) -join ' ' } else { $list[0] }
[FD]::SendMessage($e,$WM_SETTEXT,[IntPtr]::Zero,$txt)|Out-Null
"파일 이름 칸: $txt"
if($Open){ Start-Sleep -Milliseconds 500; [FD]::PostMessage($d,$WM_COMMAND,[IntPtr]1,[IntPtr]::Zero)|Out-Null; "열기 보냄" }
