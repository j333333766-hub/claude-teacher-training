﻿# 열려 있는 결재 문서(hwnd)를 문서처리 → 확인 → "결재하시겠습니까" 확인 → "정상적으로 처리" 확인 → 탭 닫기 예 순서로 처리한다.
# 예상과 다른 메시지 상자가 뜨면 누르지 않고 멈춘다.
#   pwsh -File procdoc.ps1 -Hwnd 123
param([long]$Hwnd, [switch]$AllowPII)
$S = "$HOME\.claude\skills\kedufine-gian\scripts"
function Wins { & "$S\iewin.ps1" }
function WaitFor([scriptblock]$cond, [int]$sec = 12) { $t = (Get-Date).AddSeconds($sec); while ((Get-Date) -lt $t) { $w = Wins; $r = & $cond $w; if ($r) { return $r }; Start-Sleep -Milliseconds 700 }; return $null }

$before = Wins
Start-Process pwsh -ArgumentList '-NoProfile', '-File', "$S\ieclick.ps1", '-Hwnd', "$Hwnd", '-Id', 'processdoc' -WindowStyle Hidden | Out-Null
$dlgDoc = WaitFor { param($w) $i = [array]::IndexOf($w, ($w | Where-Object { $_ -match '대화 상자 틀 \| 문서처리' } | Select-Object -First 1)); if ($i -ge 0 -and $i + 1 -lt $w.Count -and $w[$i + 1] -match '^(\d+) \| 문서 \|') { [long]$Matches[1] } }
if (-not $dlgDoc) {
  # 본문에서 개인정보가 검출되면 '계속진행하시겠습니까' 확인이 먼저 뜬다. 사용자 승인을 받은 경우에만 -AllowPII로 넘긴다.
  $pii = Wins | Where-Object { $_ -match '개인정보가 검출되었습니다. 계속진행' }
  if ($pii -and $AllowPII) { pwsh -NoProfile -File "$S\iemsg.ps1" -Must '계속진행하시겠습니까' -Button '확인' | Out-Null; $dlgDoc = WaitFor { param($w) $i = [array]::IndexOf($w, ($w | Where-Object { $_ -match '대화 상자 틀 \| 문서처리' } | Select-Object -First 1)); if ($i -ge 0 -and $i + 1 -lt $w.Count -and $w[$i + 1] -match '^(\d+) \| 문서 \|') { [long]$Matches[1] } } }
  elseif ($pii) { 'STOP: 본문 개인정보 검출 - 사용자 확인 후 -AllowPII로 다시 실행'; exit 2 }
}
if (-not $dlgDoc) { 'STOP: 문서처리 창이 뜨지 않음'; Wins; exit 1 }
"문서처리 창: $dlgDoc"
Start-Process pwsh -ArgumentList '-NoProfile', '-File', "$S\ieclick.ps1", '-Hwnd', "$dlgDoc", '-Id', 'aSubmit' -WindowStyle Hidden | Out-Null
$msg = WaitFor { param($w) $w | Where-Object { $_ -match '웹 페이지 메시지' } | Select-Object -First 1 }
if (-not $msg) { 'STOP: 확인 뒤 메시지 상자가 없음'; Wins; exit 1 }
"메시지: $msg"
if ($msg -notmatch '결재하시겠습니까') { 'STOP: 예상과 다른 메시지라 누르지 않음'; exit 1 }
pwsh -NoProfile -File "$S\iemsg.ps1" -Must '결재하시겠습니까' -Button '확인'
$ok = WaitFor { param($w) $w | Where-Object { $_ -match '웹 페이지 메시지' } | Select-Object -First 1 }
"메시지: $ok"
if ($ok -match '정상적으로 처리') { pwsh -NoProfile -File "$S\iemsg.ps1" -Must '정상적으로 처리' -Button '확인' } elseif ($ok -match '정상 완료 처리') { pwsh -NoProfile -File "$S\iemsg.ps1" -Must '정상 완료 처리' -Button '확인' } else { 'STOP: 처리 완료 메시지가 아님'; exit 1 }
# 자동발송 문서는 발송 창이 한 번 더 떴다가 닫히므로, 30초 동안 '탭을 닫으' 확인이 뜨는 대로 예를 누른다
$end = (Get-Date).AddSeconds(30); $n = 0
while ((Get-Date) -lt $end) {
  $w = Wins
  if ($w | Where-Object { $_ -match '탭을 닫으' }) { pwsh -NoProfile -File "$S\iemsg.ps1" -Must '탭을 닫으' -Button '예' | Out-Null; $n++; Start-Sleep 2; continue }
  if ($n -gt 0 -and -not ($w | Where-Object { $_ -match '^\d+ \| 문서 \| 4,' })) { break }
  Start-Sleep 1
}
"탭 닫기 $n번"
'DONE'

