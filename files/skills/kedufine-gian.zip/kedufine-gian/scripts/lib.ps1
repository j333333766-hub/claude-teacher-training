# 공용: IE 모드 창 핸들(Internet Explorer_Server)에서 HTML 문서 객체를 얻는다. 다른 스크립트가 dot-source 한다.
Add-Type @'
using System; using System.Runtime.InteropServices;
public class IeDom {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  [DllImport("oleacc.dll", PreserveSig=false)] [return: MarshalAs(UnmanagedType.IDispatch)]
  public static extern object ObjectFromLresult(IntPtr lResult, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, IntPtr wParam);
  public static object Get(IntPtr h) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT");
    IntPtr res; SendMessageTimeout(h, msg, IntPtr.Zero, IntPtr.Zero, 2, 3000, out res);
    if (res == IntPtr.Zero) return null;
    return ObjectFromLresult(res, new Guid("626FC520-A41E-11CF-A731-00A0C9082637"), IntPtr.Zero);
  }
}
'@
function Inv($o,[string]$name,[object[]]$a=$null,[string]$kind='Method'){
  $B=[Reflection.BindingFlags]
  $flag= if($kind -eq 'Get'){$B::GetProperty}elseif($kind -eq 'Set'){$B::SetProperty}else{$B::InvokeMethod}
  [System.__ComObject].InvokeMember($name,$flag,$null,$o,$a) }
function Get-Hwp([long]$Hwnd,[string]$Frame='editor1'){ $doc=[IeDom]::Get([IntPtr]$Hwnd); $doc.getElementById($Frame).contentWindow.document.getElementById($Frame) }
