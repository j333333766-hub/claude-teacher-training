# ieclick.ps1 을 시간 제한을 두고 실행한 뒤, 떠 있는 창 목록을 보여 주고 화면을 캡처한다.
# 누른 뒤 모달이 뜨면 ieclick 이 돌아오지 않으므로 -WaitSec 만 기다리고 넘어간다.
#   pwsh -File iego.ps1 -Hwnd 123 -Id processdoc -Expect "제목 일부" -Out shot.png
#   pwsh -File iego.ps1 -Hwnd 123 -Text "공람 (0)" -Out shot.png
param([long]$Hwnd, [string]$Id, [string]$Text, [string]$Expect, [string]$Out, [int]$WaitSec = 8)
$a = @('-NoProfile','-File',"`"$PSScriptRoot\ieclick.ps1`"",'-Hwnd',"$Hwnd")  # 경로에 공백(클로드 스킬) 있어 따옴표 필요
if ($Id)     { $a += @('-Id', $Id) }
if ($Text)   { $a += @('-Text', "`"$Text`"") }
if ($Expect) { $a += @('-Expect', "`"$Expect`"") }
$log = Join-Path $env:TEMP 'ieclick.log'
$p = Start-Process pwsh -ArgumentList $a -RedirectStandardOutput $log -WindowStyle Hidden -PassThru
if ($p.WaitForExit($WaitSec * 1000)) { "ieclick 종료코드 $($p.ExitCode)" } else { "ieclick 이 ${WaitSec}초 안에 안 돌아옴(모달이 떠 있을 가능성)" }
Get-Content $log -Encoding utf8 -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1
"--- 창 ---"; & "$PSScriptRoot\iewin.ps1"
if ($Out) { & "$PSScriptRoot\screen.ps1" -Out $Out }
