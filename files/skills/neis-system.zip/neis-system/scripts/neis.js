// 4세대 나이스 메인 탭(https://ice.neis.go.kr/jsp/main.jsp)에서 javascript_tool 로 한 번 실행해 도우미를 심는다.
// 그 뒤:  await NE.open('일일근무상황조회')   NE.grids()   NE.controls('button')   NE.rows(gridId)   NE.tabs()   NE.closeTab()
//         NE.keepAlive(20)   NE.status()   NE.approvals()
// (주의) 결과에 '='·'&' 많은 문자열이나 함수 원문을 돌려주면 "[BLOCKED: Cookie/query string data]". 결과는 약 1,000자에서 잘린다.
// 프레임워크: eXbuilder6(cleopatra.js). 앱 인스턴스 cpr.core.Platform.INSTANCE.getAllRunningAppInstances()[0] = app/com/main/Index
window.NE = (() => {
  const P = () => cpr.core.Platform.INSTANCE;
  const IDX = () => P().getAllRunningAppInstances().find((a) => a.app.id === 'app/com/main/Index');
  const mdi = () => IDX().lookup('mdiCn');                  // 가운데 작업 탭 묶음(MDI)
  const NAVS = ['snavAppvl', 'snavPersonal', 'snavMyMn', 'snavMn']; // 승인사항 / 개인설정 / 기본 메뉴 / 역할별 메뉴
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const T = (s) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();

  function find(label) {
    for (const id of NAVS) {
      const n = IDX().lookup(id); let hit = null;
      (function f(a) { (a || []).forEach((it) => { if (!hit && it.label === label) hit = it; try { f(it.children); } catch (e) {} }); })(n.getItems());
      if (hit) return [n, hit];
    }
    return null;
  }
  // 메뉴 이름으로 화면을 연다(왼쪽 메뉴를 누른 것과 같은 item-click 이벤트). 역할 메뉴는 그 역할 권한이 있어야 뜬다.
  async function open(label, waitSec = 15) {
    const f = find(label); if (!f) return '메뉴 없음: ' + label;
    f[0].dispatchEvent(new cpr.events.CItemEvent('item-click', { item: f[1] }));
    for (let i = 0; i < waitSec; i++) { await sleep(1000); const ai = current(); if (ai) { await sleep(1200); return '열림 ' + label + ' [' + ai.app.id.replace(/^edu\//, '') + ']'; } }
    return '열리는 중(아직 화면 없음): ' + label + ' — 탭이 뒤에 있으면 느리다. 스크린샷으로 확인';
  }
  // 지금 앞에 있는 작업 탭의 화면 앱 인스턴스
  function current() { try { const t = mdi().getSelectedTabItem(); return t && t.content && t.content.getEmbeddedAppInstance ? t.content.getEmbeddedAppInstance() : null; } catch (e) { return null; } }
  function tabs() { return mdi().getTabItems().map((t) => t.text).join(' | '); }
  function closeTab() { const t = mdi().getSelectedTabItem(); if (t && t.text !== '초기화면') { mdi().close(t); return 'closed ' + t.text; } return '초기화면'; }
  // 화면 컨트롤 읽기(id·종류·값). 단추는 lookup(id).click() 으로 누를 수 있다 — 조회 외에는 사용자 허락 뒤에.
  function controls(filterType) {
    const ai = current(); if (!ai) return '화면 없음';
    const out = [];
    const scan = (a) => a.getContainer().getAllRecursiveChildren().forEach((x) => {
      if (filterType && x.type !== filterType) return;
      if (['button', 'combobox', 'inputbox', 'dateinput', 'grid', 'checkbox', 'radiobutton'].includes(x.type)) out.push(x.type + ' ' + x.id + ' ' + T(x.value || x.text).slice(0, 20));
      if (x.type === 'embeddedapp') { try { scan(x.getEmbeddedAppInstance()); } catch (e) {} }
    });
    scan(ai); return out.join('\n');
  }
  // 그리드 머리글과 행 수(값은 돌려주지 않음 — 필요할 때만 rows 로 읽는다)
  function grids() {
    const ai = current(); if (!ai) return '화면 없음';
    return ai.getContainer().getAllRecursiveChildren().filter((x) => x.type === 'grid').map((g) => {
      const h = g.header; const heads = h.getCellIndices().slice(0, 30).map((i) => { try { return T(h.getColumn(i).getText ? h.getColumn(i).getText() : ''); } catch (e) { return ''; } }).filter(Boolean);
      let n = '?'; try { n = g.dataSet.getRowCount(); } catch (e) {}
      return g.id + ' (' + n + '행): ' + heads.join('/');
    }).join('\n');
  }
  function rows(gridId, max = 30) { // 그리드의 데이터셋 행(열 이름 기준). 개인정보는 필요한 만큼만.
    const ai = current(); const g = ai.lookup(gridId); const ds = g.dataSet; const cols = ds.getColumnNames(); const out = [];
    for (let i = 0; i < Math.min(ds.getRowCount(), max); i++) out.push(cols.map((c) => T(ds.getValue(i, c))).join(' | '));
    return cols.join(' | ') + '\n' + out.join('\n');
  }

  // 자동 로그아웃(60분) 막기: 조회 전용 통신(승인사항 건수 새로고침 subApproval)을 보내면 남은 시간이 60분으로 돌아간다(2026-10-18 시험 57:44→59:59).
  function ping() { IDX().lookup('subApproval').send(); return remain(); }
  function remain() { try { return IDX().lookup('optTime').value + ' ' + (IDX().lookup('optTime2').value || ''); } catch (e) { return '읽기 실패(로그아웃?)'; } }
  function keepAlive(min = 20) {
    clearInterval(window.__neKA);
    window.__neKA = setInterval(() => { try { ping(); window.__neKAlast = new Date().toLocaleTimeString(); } catch (e) { window.__neKAlast = 'ERR ' + e.message; } }, min * 60000);
    ping(); window.__neKAlast = new Date().toLocaleTimeString();
    return '로그인 유지 켬(' + min + '분마다)';
  }
  function status() { return '남은 시간 ' + remain() + ' / 유지 ' + (window.__neKA ? '켜짐, 마지막 ' + window.__neKAlast : '꺼짐') + ' / 작업 탭 ' + tabs(); }
  // 승인사항 건수(미결/협조함 등)
  function approvals() { const ds = IDX().lookup('dsApproval'); const c = ds.getColumnNames(); const nm = c.find((x) => /NM|Nm/.test(x)); const cnt = c.find((x) => /CNT|Cnt|cnt/.test(x)); const a = []; for (let i = 0; i < ds.getRowCount(); i++) a.push(ds.getValue(i, nm) + (cnt ? ' ' + ds.getValue(i, cnt) : '')); return a.join(', '); }
  return { open, current, tabs, closeTab, controls, grids, rows, ping, remain, keepAlive, status, approvals };
})();
'NE ready';
