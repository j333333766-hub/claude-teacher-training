﻿# K-에듀파인 공문을 WXSClient 창 대신 엣지 IE 모드 탭으로 열도록 설정한다.
# 사용: install.ps1 -KedufineHost klef.ice.go.kr   (자기 교육청 K-에듀파인 주소)
# 되돌리기: uninstall.ps1
param([string]$KedufineHost)
$ErrorActionPreference = 'Stop'
$dir = 'C:\ProgramData\KEdufineTab'
$list = 'file:///C:/ProgramData/KEdufineTab/sitelist.xml'
$pol = 'HKLM:\SOFTWARE\Policies\Microsoft\Edge'
$cls = 'HKCU:\Software\Classes\wxsclient'

function Fail($msg) { Write-Host "설치 실패: $msg"; exit 1 }

# 0) K-에듀파인 주소
if (-not $KedufineHost) {
    $KedufineHost = Read-Host 'K-에듀파인 주소를 입력하세요 (예: klef.ice.go.kr - K-에듀파인 화면 주소창의 https:// 다음 부분)'
}
$KedufineHost = ($KedufineHost.Trim().ToLower() -replace '^https?://', '' -replace '[:/].*$', '')
if ($KedufineHost -notmatch '^[a-z0-9-]+(\.[a-z0-9-]+)+$') { Fail "주소 형식이 이상합니다: '$KedufineHost'" }

# 1) 원래 프로그램(WXSClient) 위치 확인 - 없으면 K-에듀파인 프로그램 설치가 안 된 PC다.
$orig = (Get-ItemProperty 'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\wxsclient\shell\open\command' -ErrorAction SilentlyContinue).'(default)'
if (-not $orig -or $orig -notmatch '^"?([^"]+?\.exe)') { Fail 'WXSClient(K-에듀파인 문서 프로그램)가 설치되어 있지 않습니다. K-에듀파인 설치프로그램을 먼저 설치하세요.' }
$wxsExe = $Matches[1]

# 2) 이미 다른 IE 모드 사이트 목록(학교·교육청 정책)이 있으면 덮어쓰지 않는다.
$p = Get-ItemProperty -Path $pol -ErrorAction SilentlyContinue
if ($p -and $p.InternetExplorerIntegrationSiteList -and $p.InternetExplorerIntegrationSiteList -ne $list) {
    Fail "이 PC에는 이미 다른 IE 모드 사이트 목록 정책이 있습니다($($p.InternetExplorerIntegrationSiteList)). 덮어쓰지 않고 중단합니다."
}

# 3) 파일 배치(경로에 한글이 없어야 정책의 file:/// 주소가 안전하다)
New-Item -ItemType Directory -Force -Path $dir | Out-Null
foreach ($f in 'wxs2edge.vbs', 'policy.ps1', 'uninstall.ps1') {
    $from = Join-Path $PSScriptRoot $f
    if ((Resolve-Path $from).Path -ne (Join-Path $dir $f)) { Copy-Item $from $dir -Force }
}
Set-Content -Path "$dir\config.txt" -Value @($KedufineHost, $wxsExe) -Encoding Unicode
# 버전 번호가 올라가야 엣지가 목록을 다시 읽는다.
$ver = (Get-Date).ToString('yyMMddHHmm')
@"
<site-list version="$ver">
  <created-by>
    <tool>KEdufineTab</tool>
    <version>$ver</version>
    <date-created>$((Get-Date).ToString('MM/dd/yyyy HH:mm:ss'))</date-created>
  </created-by>
  <site url="$KedufineHost/bms/cz/cb/prc/" allow-redirect="true">
    <compat-mode>Default</compat-mode>
    <open-in>IE11</open-in>
  </site>
</site-list>
"@ | Set-Content -Path "$dir\sitelist.xml" -Encoding UTF8

# 4) 엣지 IE 모드 정책(관리자 권한 필요 - 권한 요청 창이 한 번 뜬다)
try {
    Start-Process powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$dir\policy.ps1`""
} catch { }
$p = Get-ItemProperty -Path $pol -ErrorAction SilentlyContinue
if (-not $p -or $p.InternetExplorerIntegrationLevel -ne 1 -or $p.InternetExplorerIntegrationSiteList -ne $list) {
    # 정책 없이 연결만 바뀌면 공문이 일반 탭에서 깨져 열리므로, 연결은 건드리지 않고 끝낸다.
    Remove-Item $cls -Recurse -Force -ErrorAction SilentlyContinue
    Fail '엣지 정책을 넣지 못했습니다(권한 요청을 거절했거나 관리자 권한이 없음). 공문은 원래대로 열립니다.'
}

# 5) wxsclient:// 프로토콜을 사용자 단위로 덮어써서 wxs2edge.vbs 로 보낸다.
New-Item -Path "$cls\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path $cls -Name '(default)' -Value 'URL:K-edufine document in Edge tab'
Set-ItemProperty -Path $cls -Name 'URL Protocol' -Value ''
Set-ItemProperty -Path "$cls\shell\open\command" -Name '(default)' -Value "`"$env:WINDIR\System32\wscript.exe`" `"$dir\wxs2edge.vbs`" `"%1`""

Write-Host "설치 완료 ($KedufineHost)."
Write-Host '엣지 주소창에 edge://restart 를 입력해 엣지를 완전히 다시 시작한 뒤 공문을 열어 보세요.'
