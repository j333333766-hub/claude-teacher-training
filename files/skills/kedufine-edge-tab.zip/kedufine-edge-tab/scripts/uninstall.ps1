﻿# install.ps1 이 바꾼 것을 모두 되돌린다. 공문은 다시 WXSClient 창으로 열린다.
$dir = 'C:\ProgramData\KEdufineTab'
$list = 'file:///C:/ProgramData/KEdufineTab/sitelist.xml'

# 1) 프로토콜 연결 원복(이것만으로 공문은 즉시 다시 WXSClient 로 열린다)
$cls = 'HKCU:\Software\Classes\wxsclient'
if (Test-Path $cls) { Remove-Item -Path $cls -Recurse -Force }

# 2) 엣지 IE 모드 정책 제거(관리자 권한 필요 - 권한 요청 창이 한 번 뜬다)
$p = Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' -ErrorAction SilentlyContinue
if ($p -and $p.InternetExplorerIntegrationSiteList -eq $list) {
    $policy = Join-Path $PSScriptRoot 'policy.ps1'
    try {
        Start-Process powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$policy`"", '-Remove'
    } catch { }
    $p = Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' -ErrorAction SilentlyContinue
    if ($p -and $p.InternetExplorerIntegrationSiteList -eq $list) {
        Write-Host '공문은 원래대로(WXSClient 창) 열립니다. 다만 권한 요청이 거절되어 엣지 IE 모드 정책은 남아 있습니다. 다시 실행해 권한을 허용하면 지워집니다.'
        exit 1
    }
}

Write-Host '원래대로 되돌렸습니다. 엣지 주소창에 edge://restart 를 입력해 엣지를 다시 시작해 주세요.'
