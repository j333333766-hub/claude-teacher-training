﻿# 엣지 IE 모드 정책을 넣거나(-Remove 없이) 뺀다(-Remove). 관리자 권한으로 실행된다.
param([switch]$Remove)
$pol = 'HKLM:\SOFTWARE\Policies\Microsoft\Edge'
$list = 'file:///C:/ProgramData/KEdufineTab/sitelist.xml'
if ($Remove) {
    $p = Get-ItemProperty -Path $pol -ErrorAction SilentlyContinue
    # 우리가 넣은 목록일 때만 지운다(학교·교육청이 따로 넣은 정책은 건드리지 않는다).
    if ($p -and $p.InternetExplorerIntegrationSiteList -eq $list) {
        foreach ($n in 'InternetExplorerIntegrationLevel', 'InternetExplorerIntegrationSiteList', 'InternetExplorerIntegrationSiteRedirect') {
            Remove-ItemProperty -Path $pol -Name $n -ErrorAction SilentlyContinue
        }
    }
} else {
    # 목록에 있는 공문 경로만 IE 모드로 열고, 그 탭 안의 이동은 IE 모드로 유지한다.
    if (-not (Test-Path $pol)) { New-Item -Path $pol -Force | Out-Null }
    Set-ItemProperty -Path $pol -Name 'InternetExplorerIntegrationLevel' -Value 1 -Type DWord
    Set-ItemProperty -Path $pol -Name 'InternetExplorerIntegrationSiteList' -Value $list -Type String
    Set-ItemProperty -Path $pol -Name 'InternetExplorerIntegrationSiteRedirect' -Value 2 -Type DWord
}
