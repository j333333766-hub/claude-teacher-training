' K-edufine: open documents in an Edge (IE mode) tab instead of WXSClient.exe
' Registered as the per-user handler of the wxsclient:// protocol by install.ps1.
' Reads config.txt (line 1: K-edufine host, line 2: original WXSClient.exe path).
' Anything unexpected falls back to the original WXSClient.exe.
Option Explicit

Dim sh, fso, arg, url, kHost, wxsExe
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

If WScript.Arguments.Count = 0 Then WScript.Quit 1
arg = WScript.Arguments(0)

kHost = ""
wxsExe = "C:\Program Files (x86)\kedu\WXSClient.exe"
ReadConfig

url = ""
On Error Resume Next
url = ExtractUrl(arg)
On Error GoTo 0

If IsSafeUrl(url) And fso.FileExists(EdgePath()) Then
    sh.Run """" & EdgePath() & """ """ & url & """", 1, False
Else
    Fallback
End If

Sub ReadConfig()
    Dim p, f, line
    p = fso.GetParentFolderName(WScript.ScriptFullName) & "\config.txt"
    If Not fso.FileExists(p) Then Exit Sub
    On Error Resume Next
    Set f = fso.OpenTextFile(p, 1, False, -1)
    If Not f.AtEndOfStream Then kHost = LCase(Trim(f.ReadLine))
    If Not f.AtEndOfStream Then
        line = Trim(f.ReadLine)
        If Len(line) > 0 Then wxsExe = line
    End If
    f.Close
    On Error GoTo 0
End Sub

Sub Fallback()
    If fso.FileExists(wxsExe) Then
        sh.Run """" & wxsExe & """ """ & Replace(arg, """", "") & """", 1, False
    End If
End Sub

Function EdgePath()
    Dim p
    p = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
    If Not fso.FileExists(p) Then p = "C:\Program Files\Microsoft\Edge\Application\msedge.exe"
    EdgePath = p
End Function

Function ExtractUrl(s)
    Dim re, m, b64
    ExtractUrl = ""
    Set re = New RegExp
    re.Pattern = "[&/?]url:([A-Za-z0-9+/=%_-]+)"
    re.IgnoreCase = True
    Set m = re.Execute(s)
    If m.Count = 0 Then Exit Function
    b64 = m(0).SubMatches(0)
    b64 = Replace(b64, "%3D", "=", 1, -1, 1)
    b64 = Replace(b64, "%2B", "+", 1, -1, 1)
    b64 = Replace(b64, "%2F", "/", 1, -1, 1)
    ExtractUrl = DecodeBase64(b64)
End Function

Function DecodeBase64(b64)
    Dim xml, node, stream
    Set xml = CreateObject("MSXML2.DOMDocument")
    Set node = xml.createElement("b")
    node.DataType = "bin.base64"
    node.Text = b64
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1
    stream.Open
    stream.Write node.nodeTypedValue
    stream.Position = 0
    stream.Type = 2
    stream.Charset = "us-ascii"
    DecodeBase64 = stream.ReadText
    stream.Close
End Function

' Only https URLs on the configured K-edufine host, with no characters that could
' break out of the quoted command-line argument, are handed to Edge.
Function IsSafeUrl(u)
    Dim prefix, rest, re
    IsSafeUrl = False
    If Len(kHost) = 0 Then Exit Function
    prefix = "https://" & kHost
    If Len(u) < Len(prefix) + 1 Then Exit Function
    If LCase(Left(u, Len(prefix))) <> prefix Then Exit Function
    rest = Mid(u, Len(prefix) + 1, 1)
    If rest <> "/" And rest <> ":" Then Exit Function
    Set re = New RegExp
    re.Pattern = "^[A-Za-z0-9:/?&=%._~+\-#,;@!$*()]+$"
    IsSafeUrl = re.Test(u)
End Function
