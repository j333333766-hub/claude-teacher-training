---
name: kedufine-edge-tab
description: K-에듀파인(업무관리시스템) 공문이 별도 창(WXSClient 프로그램)이 아니라 엣지 브라우저의 탭에서 열리도록 설정·점검·원복한다. 사용자가 "K-에듀파인 공문을 새 탭에서 열고 싶다", "공문이 새 창으로 떠서 불편하다", "에듀파인 문서 창을 탭으로", "결재 문서가 따로 창으로 뜬다"라고 하거나, 이 설정을 한 뒤 "공문이 안 열린다", "컨트롤이 설치되어 있지 않다는 메시지가 뜬다", "원래대로 되돌려 달라"고 할 때 반드시 이 스킬을 쓴다. 다른 선생님 PC에 같은 설정을 해 주거나 설치 파일을 나눠 주려는 요청에도 쓴다.
---

# K-에듀파인 공문을 엣지 탭으로 열기

## 무엇을 하는 스킬인가

K-에듀파인에서 공문을 누르면 엣지 창이 아니라 `WXSClient.exe`라는 별도 프로그램 창이 뜬다. 이 스킬은 그 공문을 **엣지의 IE 모드 탭**에서 열리게 바꾼다.

브라우저 팝업 설정이나 "팝업을 탭으로" 확장 프로그램으로는 해결되지 않는다. 이유를 알아야 엉뚱한 곳을 뒤지지 않는다.

- 목록에서 공문을 누르면 페이지가 `wxsclient://...` 주소를 부르고, 윈도우가 이 주소에 연결된 `WXSClient.exe`를 실행한다. 브라우저가 창을 여는 게 아니다.
- 공문 페이지는 한글 컨트롤(`HwpODTCtrl`) 등 ActiveX가 있어야 본문이 보인다. `WXSClient.exe`는 IE 엔진을 품은 껍데기라서 이게 된다. 엣지 일반 탭은 ActiveX를 못 돌린다.
- 엣지 **IE 모드** 탭은 IE 엔진으로 페이지를 그리므로 ActiveX가 돈다. 그래서 `wxsclient://` 연결을 가로채 공문 주소를 엣지로 넘기고, 그 주소가 IE 모드로 열리도록 엣지 정책에 등록한다.

바뀌는 것은 세 가지뿐이다.

| 위치 | 내용 |
|---|---|
| `C:\ProgramData\KEdufineTab\` | `wxs2edge.vbs`, `config.txt`, `sitelist.xml`, `policy.ps1`, `uninstall.ps1` |
| `HKCU\Software\Classes\wxsclient` | `wxsclient://` 를 `wxs2edge.vbs`로 연결(현재 사용자만) |
| `HKLM\SOFTWARE\Policies\Microsoft\Edge` | `InternetExplorerIntegrationLevel=1`, `...SiteList`, `...SiteRedirect=2` (PC 전체, 관리자 권한 필요) |

## 진행 순서

### 1. 먼저 확인할 것

- **K-에듀파인 주소**: 교육청마다 다르다(인천은 `klef.ice.go.kr`). 사용자에게 K-에듀파인 화면의 주소창을 보고 `https://` 다음 부분을 알려 달라고 한다. 추측해서 넣지 않는다. 주소가 틀리면 설치는 되지만 공문이 계속 원래 창으로 열린다.
- **이미 설치돼 있는지**: `C:\ProgramData\KEdufineTab\config.txt`가 있으면 재설치·점검 상황이다.
- 읽기 전용 점검은 직접 해도 된다. 예:
  ```powershell
  Get-ItemProperty 'Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\wxsclient\shell\open\command'   # 원래 프로그램
  Test-Path 'HKCU:\Software\Classes\wxsclient'                                                    # 연결을 바꿨는지
  Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Edge'                                       # 엣지 정책
  ```

### 2. 설치는 사용자가 직접 실행한다

레지스트리의 프로토콜 연결과 브라우저 보안 정책(IE 모드, ActiveX 허용 범위)을 바꾸는 일이다. 무엇이 바뀌는지 위 표대로 설명한 뒤, 사용자가 직접 실행하게 한다. 대신 실행하지 않는다.

Claude Code라면 프롬프트에 아래를 입력하게 한다. `!` 명령은 bash로 실행되어 역슬래시가 사라지므로 **경로는 슬래시(`/`)로** 쓴다.

```
! powershell -ExecutionPolicy Bypass -File "<이 스킬 폴더>/scripts/install.ps1" -KedufineHost <주소>
```

`-KedufineHost`는 꼭 붙인다. 빼면 스크립트가 주소를 물어보는데, `!` 실행에서는 입력을 받지 못해 멈춘다.

실행 중 관리자 권한 요청 창이 한 번 뜬다. 거절하거나 관리자 암호를 모르면 "설치 실패"가 나오고 아무것도 바뀌지 않는다(연결만 바뀌고 정책이 빠진 반쪽 상태를 스크립트가 막는다).

### 3. 엣지를 완전히 다시 시작

엣지는 창을 다 닫아도 뒤에서 계속 돌아서 새 정책을 읽지 않는다. 주소창에 `edge://restart`를 입력하게 한다. 저장 안 한 작업이 있으면 먼저 마무리하도록 알려 준다. K-에듀파인은 다시 로그인해야 한다.

### 4. 확인

1. `edge://compat/enterprise` → "엔터프라이즈 사이트 목록"에 버전 번호와 위치(`file:///C:/ProgramData/KEdufineTab/sitelist.xml`)가 채워지고, 표에 `<주소>/bms/cz/cb/prc/`가 보여야 한다. 엣지를 켠 직후에는 1분쯤 걸릴 수 있다.
2. 목록이 보인 뒤 결재대기 등에서 공문 하나를 연다. 새 탭으로 열리고, 탭 제목 앞·주소창 왼쪽에 IE 아이콘이 있고, 한글 본문이 보이면 성공이다.
3. 중요하지 않은 건으로 결재 처리, 첨부파일 열기·저장, 닫기, 다른 문서함(공람·접수함·문서등록대장·기안)도 한 번씩 해 보게 한다. 본문 보기 외의 동작은 PC·교육청마다 다를 수 있어서, 확인 전에는 된다고 말하지 않는다.

### 5. 되돌리기

```
! powershell -ExecutionPolicy Bypass -File "C:/ProgramData/KEdufineTab/uninstall.ps1"
```

연결 원복은 권한 없이 즉시 되므로, 급한 결재가 막혔을 때는 이것부터 실행하게 한다. 정책 제거에는 권한 요청 창이 한 번 더 뜬다. 끝나면 `edge://restart`.

## 증상별 대처

| 증상 | 원인과 조치 |
|---|---|
| 새 탭은 뜨는데 "문서관리 시스템에 필요한 컨트롤이 설치되어 있지 않거나…" 메시지가 나오고 닫힘. 주소창에 IE 아이콘 없음 | IE 모드가 안 걸렸다. `edge://compat/enterprise`에 목록이 비어 있으면 엣지를 `edge://restart`로 재시작. 목록은 있는데 공문 주소의 경로가 `/bms/cz/cb/prc/`가 아니면 `sitelist.xml`에 그 경로를 `<site>`로 추가하고 `version`을 올린 뒤 "강제 업데이트" |
| IE 아이콘이 있는데도 컨트롤 메시지가 나옴 | ActiveX 사용이 막혀 있다. K-에듀파인 설치프로그램(한글 컨트롤 포함)이 깔려 있는지, K-에듀파인 주소가 신뢰할 수 있는 사이트에 있는지 확인. 원래 `WXSClient` 창에서도 안 열리는 PC라면 이 스킬의 문제가 아니다 |
| 설치 후에도 여전히 별도 창으로 열림 | `config.txt` 1행의 주소가 실제 K-에듀파인 주소와 다르다(다르면 안전하게 원래 프로그램으로 넘긴다). 주소를 확인해 다시 설치 |
| `edge://compat/enterprise`가 재시작 후에도 비어 있음 | `edge://policy`에서 `InternetExplorerIntegrationSiteList`가 보이는지, 오류 표시가 있는지 확인 |
| "이미 다른 IE 모드 사이트 목록 정책이 있습니다"로 설치 중단 | 학교·교육청이 넣은 정책이 있다. 덮어쓰면 다른 업무 사이트가 깨질 수 있으므로 진행하지 않고 사용자에게 알린다 |
| 어느 날 갑자기 공문이 안 열림 | K-에듀파인·엣지·한글 업데이트로 깨졌을 수 있다. 먼저 원복해서 업무를 살리고, 그다음 원인을 본다 |

`sitelist.xml`을 고칠 때는 `version` 숫자를 반드시 올린다. 숫자가 같으면 엣지가 다시 읽지 않는다.

## 다른 사람에게 나눠 줄 때

Claude가 없는 사람도 쓸 수 있다. `scripts` 폴더를 통째로 전달하고 `README.md`(같은 폴더)를 함께 보게 한다. `install.bat`을 더블클릭하면 주소를 물어본 뒤 설치하고, `uninstall.bat`으로 되돌린다.

전달할 때 함께 알려 줄 것:

- 인천(`klef.ice.go.kr`)의 결재대기 공문에서 본문이 뜨는 것까지 확인된 방법이다. 다른 교육청, 결재 처리·첨부·기안은 각자 확인이 필요하다.
- 교육청이 지원하는 공식 방법이 아니다. 문제가 생기면 원복하고 원래 방식으로 쓰면 된다.
- PC 전체에 엣지 IE 모드 정책이 들어가므로, 관리자 권한이 없는 PC에서는 설치되지 않는다.
