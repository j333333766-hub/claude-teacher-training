# 엣지에서 제목에 -Match 가 들어간 탭을 앞으로 가져온다(UI Automation, 마우스 안 씀).
# 뒤에 깔린 IE 모드 탭은 저장 대화 상자를 띄우지 않고 캡처도 까맣게 나오므로, 공문 탭을 다루기 전에 먼저 부른다.
#   pwsh -File tabfront.ps1 -Match "꿈너머꿈"
param([Parameter(Mandatory)][string]$Match)
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$A = [System.Windows.Automation.AutomationElement]; $TS = [System.Windows.Automation.TreeScope]
$edge = $A::RootElement.FindAll($TS::Children, (New-Object System.Windows.Automation.PropertyCondition($A::ClassNameProperty, 'Chrome_WidgetWin_1'))) |
  Where-Object { $_.Current.Name -like '*Microsoft*Edge*' } | Select-Object -First 1
if (-not $edge) { 'NO EDGE'; exit 1 }
$tabs = $edge.FindAll($TS::Descendants, (New-Object System.Windows.Automation.PropertyCondition($A::ControlTypeProperty, [System.Windows.Automation.ControlType]::TabItem)))
$t = $tabs | Where-Object { $_.Current.Name -like "*$Match*" } | Select-Object -First 1
if (-not $t) { 'NO TAB: ' + (($tabs | ForEach-Object { $_.Current.Name }) -join ' || '); exit 1 }
$t.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Select()
Start-Sleep 1
"OK $($t.Current.Name)"
