# 과제카드 칸 옆 돋보기(과제카드선택)로 창을 열고 -Match 가 들어간 카드를 골라 확인까지 누른다.
# -List 를 주면 고르지 않고 목록만 보여 준다(나의과제카드함에 있는 카드만 나옴).
#   pwsh -File tkpick.ps1 -Hwnd <문서 창> -Match "유관기관협조"
param([Parameter(Mandatory)][long]$Hwnd, [string]$Match = '유관기관협조', [switch]$List)
. "$PSScriptRoot\common.ps1"
$r = Js $Hwnd "var im=document.getElementsByTagName('img'),a=null; for(var i=0;i<im.length;i++){ if((im[i].alt||'').indexOf('과제카드선택')>=0 && im[i].offsetWidth>0){ a=im[i].parentNode; break; } } if(!a) return 'no img'; setTimeout(function(){ a.click(); },200); return 'clicked';"
if ($r -notmatch 'clicked') { "ABORT: 과제카드선택 버튼이 없음($r) — 결재선을 먼저 나(본인)로 바꿨는지 확인"; exit 1 }
Start-Sleep 4
$D = NewDlg $Hwnd
if (-not $D) { 'ABORT: 과제카드 창이 안 뜸'; exit 1 }
"과제카드 창: $D"
if ($List) { pwsh -NoProfile -File "$GIAN\tkcard.ps1" -Dlg $D -List; exit 0 }
pwsh -NoProfile -File "$GIAN\tkcard.ps1" -Dlg $D -Match $Match
Start-Sleep 3
$v = Js $Hwnd "var a1=document.getElementById('tkcrdInfoList'), a2=document.getElementById('taskInfo'); return ((a1?a1.innerText:'')+' '+(a2?a2.innerText:'')).replace(/\s+/g,' ');"
"DONE 과제카드=$v"
