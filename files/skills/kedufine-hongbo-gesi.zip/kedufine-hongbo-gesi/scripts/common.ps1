# 공용: 다른 kedufine 스킬의 검증된 스크립트 경로와 작은 도우미. 다른 스크립트가 dot-source 한다.
$GIAN = "$HOME\.claude\skills\kedufine-gian\scripts"            # iewin, iejs(5.1), tkcard, procdoc, wincap
$SAVE = "$HOME\.claude\skills\kedufine-gongmun-jeojang\scripts" # ieclick, iesel, iecheck, ieanchor, iemsg

function Wins { & "$GIAN\iewin.ps1" }
# 페이지 JS 실행은 반드시 Windows PowerShell 5.1 (pwsh 7 은 documentElement 가 null)
function Js([long]$Hwnd, [string]$Code) { powershell.exe -NoProfile -File "$GIAN\iejs.ps1" -Hwnd $Hwnd -Code $Code }
# 누르면 모달이 떠서 돌아오지 않는 클릭: 따로 띄우고 몇 초만 기다린다
function ClickBg([long]$Hwnd, [string[]]$ClickArgs, [int]$Wait = 5) {
  $a = @('-NoProfile', '-File', "$SAVE\ieclick.ps1", '-Hwnd', "$Hwnd") + $ClickArgs
  $p = Start-Process pwsh -ArgumentList $a -PassThru -WindowStyle Hidden
  Start-Sleep $Wait; if (-not $p.HasExited) { $p.Kill() }
}
# 문서 창(136314 처럼 큰 '문서')이 아닌 새 '문서' 창 = 방금 뜬 대화 상자
function NewDlg([long]$Main, [int]$Tries = 10) {
  for ($i = 0; $i -lt $Tries; $i++) {
    $h = (Wins | Where-Object { $_ -match '\| 문서 \|' -and $_ -notmatch "^$Main " } | Select-Object -First 1) -replace ' \|.*', ''
    if ($h) { return [long]$h }; Start-Sleep 1
  }
  return $null
}
function Msgs { pwsh -NoProfile -File "$SAVE\iemsg.ps1" }
function MsgOk([string]$Must) { pwsh -NoProfile -File "$SAVE\iemsg.ps1" -Must $Must -Button '확인' }
