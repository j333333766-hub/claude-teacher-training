# 열린 공문 창의 본문(한글 컨트롤 editor1)을 텍스트로 뽑아 UTF-8 파일로 저장한다. 표·링크 주소까지 그대로 나온다.
#   pwsh -File bodytext.ps1 -Hwnd <문서 창> -Out body.txt
param([Parameter(Mandatory)][long]$Hwnd, [Parameter(Mandatory)][string]$Out)
. "$HOME\.claude\skills\kedufine-gian\scripts\lib.ps1"
$h = Get-Hwp $Hwnd 'editor1'
$t = Inv $h 'GetTextFile' @('TEXT', '')
[IO.File]::WriteAllText($Out, $t, [Text.Encoding]::UTF8)
"saved $Out ($($t.Length)자)"
# 첨부 파일 이름도 함께 보여 준다
$doc = [IeDom]::Get([IntPtr]$Hwnd)
foreach ($a in @($doc.getElementsByTagName('a'))) {
  $x = [string]$a.innerText
  if ($x -match '\.(pdf|hwp|hwpx|xlsx?|docx?|pptx?|zip|jpg|png)\s*$') { "첨부: $($x.Trim())" }
}
