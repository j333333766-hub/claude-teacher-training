# 결재경로 탭의 '나의결재선'을 -Option(기본 '나(본인)')으로 바꾸고 "나의결재선 변경이 정상적으로 처리" 확인을 누른다.
# 접수 공문(업무관리자 단계)은 이걸 해야 업무담당자(본인)가 들어가 문서처리가 된다.
#   pwsh -File myroute.ps1 -Hwnd <문서 창> [-Option "나(본인)"]
param([Parameter(Mandatory)][long]$Hwnd, [string]$Option = '나(본인)')
. "$PSScriptRoot\common.ps1"
# 결재경로 '탭'(초록 '결재경로' 버튼과 이름이 같으므로 글자로 누르지 않고 tabopen 을 부른다)
Js $Hwnd "tabopen('tabarea01'); var s=document.getElementById('streReportCours'); return s && s.offsetWidth>0 ? 'tab ok' : 'no select';"
$list = pwsh -NoProfile -File "$SAVE\iesel.ps1" -Hwnd $Hwnd
$line = $list | Where-Object { $_ -match 'id=streReportCours' } | Select-Object -First 1
if ($line -notmatch '^\[(\d+)\]') { "ABORT: 나의결재선 드롭다운을 못 찾음`n$list"; exit 1 }
$idx = $Matches[1]
$p = Start-Process pwsh -ArgumentList '-NoProfile', '-File', "$SAVE\iesel.ps1", '-Hwnd', "$Hwnd", '-Index', $idx, '-Option', $Option -PassThru -WindowStyle Hidden
Start-Sleep 5; if (-not $p.HasExited) { $p.Kill() }
$m = Msgs; $m
if ($m -match '나의결재선 변경이 정상적으로') { MsgOk '나의결재선 변경이 정상적으로'; "DONE 나의결재선=$Option" } else { 'CHECK: 예상한 확인 창이 아님 — 캡처로 확인'; exit 1 }
