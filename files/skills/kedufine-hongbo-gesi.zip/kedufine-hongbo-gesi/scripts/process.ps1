# 열린 공문 한 건을 공람 → 나의결재선 → 과제카드 순서로 처리하고, 페이지 값을 읽어 세 가지가 모두 맞는지 스스로 검증한다.
# -Process 를 주면 검증이 통과했을 때만 문서처리(procdoc.ps1)까지 한다. 하나라도 어긋나면 멈추고 캡처를 남긴다.
#   pwsh -File process.ps1 -Hwnd <문서 창> -Title "<탭 제목 일부>" [-Group "2026 ○○중 교원 전체"] [-Card "유관기관협조"] [-Process] [-Shot 경로.png]
# 이미 끝난 단계(공람 수 > 0, 결재선 = 나(본인), 과제카드 채워짐)는 건너뛴다 — 중간에 멈춘 뒤 다시 돌려도 된다.
param([Parameter(Mandatory)][long]$Hwnd, [Parameter(Mandatory)][string]$Title,
  [string]$Group = '2026 ○○중 교원 전체', [string]$Card = '유관기관협조', [string]$Route = '나(본인)',
  [switch]$Process, [switch]$CheckOnly, [string]$Shot = "$env:TEMP\kedufine_hongbo_check.png")
. "$PSScriptRoot\common.ps1"

function State {
  $r = Js $Hwnd "var g='?',as=document.getElementsByTagName('a'); for(var i=0;i<as.length;i++){ var t=(as[i].innerText||'').replace(/\s/g,''); var m=t.match(/^공람\((\d+)\)$/); if(m){ g=m[1]; break; } } var s=document.getElementById('streReportCours'), r=s? s.options[s.selectedIndex].text : '?'; var a1=document.getElementById('tkcrdInfoList'), a2=document.getElementById('taskInfo'); var c=((a1?a1.innerText:'')+' '+(a2?a2.innerText:'')).replace(/\s+/g,' '); return g+'|'+r+'|'+c;"
  $p = "$r".Split('|')
  [pscustomobject]@{ Gongram = $p[0]; Route = $p[1]; Card = ($p[2..($p.Count - 1)] -join '|').Trim() }
}
function Front { pwsh -NoProfile -File "$PSScriptRoot\tabfront.ps1" -Match $Title | Out-Null }

Front
$s = State; "처음 상태: 공람=$($s.Gongram) 결재선=$($s.Route) 과제카드=$($s.Card)"
if ($CheckOnly) { exit 0 }   # 읽기만(아무것도 바꾸지 않음)

if (-not ($s.Gongram -match '^\d+$' -and [int]$s.Gongram -gt 0)) {
  pwsh -NoProfile -File "$PSScriptRoot\gongram.ps1" -Hwnd $Hwnd -Group $Group | Select-Object -Last 2
  Front
}
$s = State
if ($s.Route -ne $Route) {
  pwsh -NoProfile -File "$PSScriptRoot\myroute.ps1" -Hwnd $Hwnd -Option $Route | Select-Object -Last 1
  Front
}
$s = State
if ($s.Card -notlike "*$Card*") {
  pwsh -NoProfile -File "$PSScriptRoot\tkpick.ps1" -Hwnd $Hwnd -Match $Card | Select-Object -Last 1
  Front
}

Start-Sleep 1
$s = State
$ok = ($s.Gongram -match '^\d+$' -and [int]$s.Gongram -gt 0) -and ($s.Route -eq $Route) -and ($s.Card -like "*$Card*")
pwsh -NoProfile -File "$GIAN\wincap.ps1" -Hwnd $Hwnd -Out $Shot | Out-Null
"검증: 공람=$($s.Gongram) 결재선=$($s.Route) 과제카드=$($s.Card) → $(if($ok){'통과'}else{'불일치'})  (캡처 $Shot)"
if (-not $ok) { 'STOP: 검증 불일치 — 캡처를 보고 해당 단계를 다시 하거나 사용자에게 묻는다'; exit 1 }
if (-not $Process) { 'READY: 문서처리 전 단계까지 완료(-Process 로 다시 실행하면 문서처리)'; exit 0 }

$out = pwsh -NoProfile -File "$GIAN\procdoc.ps1" -Hwnd $Hwnd
$out
if (($out -join "`n") -match '정상적으로 처리' -and ($out -join "`n") -match 'DONE') { 'DONE: 문서처리 완료' } else { 'STOP: 문서처리 결과를 확인할 것'; exit 1 }
