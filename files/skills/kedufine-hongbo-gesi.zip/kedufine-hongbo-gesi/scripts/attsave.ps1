# 공문 창의 첨부 하나를 내려받아 -Dest 폴더(기본: 다운로드)로 옮긴다.
# 순서: 첨부 줄 체크 → PC저장 → '저장하기'(폴더 고르기) 창에서 지금 보이는 폴더 그대로 [저장](BM_CLICK) → 그 폴더에 생긴 파일을 -Dest 로 옮김.
# (폴더 고르기 창은 주소칸·탐색 창이 자동화로 바뀌지 않아서, 그 자리에 저장한 뒤 옮기는 방식으로 확인했다. 2026-10-18)
# 먼저 tabfront.ps1 로 공문 탭을 앞으로 가져올 것 — 뒤에 깔린 탭에서는 저장 창이 안 뜬다.
#   pwsh -File attsave.ps1 -Hwnd <문서 창> -Match "운영계획서"
param([Parameter(Mandatory)][long]$Hwnd, [Parameter(Mandatory)][string]$Match, [string]$Dest = "$HOME\Downloads")
. "$PSScriptRoot\common.ps1"
Add-Type @'
using System; using System.Text; using System.Runtime.InteropServices; using System.Collections.Generic;
public class SvD { public delegate bool P(IntPtr h, IntPtr l);
[DllImport("user32.dll")] public static extern bool EnumWindows(P p, IntPtr l);
[DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr h, P p, IntPtr l);
[DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
[DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
static string T(IntPtr h){ var s=new StringBuilder(1024); GetWindowText(h,s,1024); return s.ToString(); }
static string C(IntPtr h){ var s=new StringBuilder(256); GetClassName(h,s,256); return s.ToString(); }
public static IntPtr Dlg(){ IntPtr r=IntPtr.Zero; EnumWindows((h,l)=>{ if(IsWindowVisible(h) && C(h)=="#32770" && T(h)=="저장하기"){ r=h; return false; } return true; },IntPtr.Zero); return r; }
public static string Addr(IntPtr d){ string r=""; EnumChildWindows(d,(k,l)=>{ string t=T(k); if(t.StartsWith("주소: ")){ r=t.Substring(4); return false; } return true; },IntPtr.Zero); return r; }
public static IntPtr Btn(IntPtr d, string name){ IntPtr r=IntPtr.Zero; EnumChildWindows(d,(k,l)=>{ if(T(k)==name){ r=k; return false; } return true; },IntPtr.Zero); return r; } }
'@
$m = $Match.Replace("'", "\'")
$r = Js $Hwnd "var as=document.getElementsByTagName('a'),tr=null; for(var i=0;i<as.length;i++){ if((as[i].innerText||'').indexOf('$m')>=0){ tr=as[i]; while(tr && tr.tagName!='TR') tr=tr.parentNode; break; } } if(!tr) return 'no row'; var ins=tr.getElementsByTagName('input'),cb=null; for(var j=0;j<ins.length;j++) if(ins[j].type=='checkbox') cb=ins[j]; if(!cb) return 'no cb'; if(!cb.checked) cb.click(); var b=document.getElementById('btnAttSave'); setTimeout(function(){ b.click(); },200); return 'ok';"
if ($r -notmatch 'ok') { "ABORT: 첨부 줄을 못 찾음 ($r)"; exit 1 }
$d = [IntPtr]::Zero; for ($i = 0; $i -lt 30 -and $d -eq [IntPtr]::Zero; $i++) { Start-Sleep -Milliseconds 500; $d = [SvD]::Dlg() }
if ($d -eq [IntPtr]::Zero) { "ABORT: 저장하기 창이 안 뜸 (공문 탭이 앞에 있는지 확인)"; exit 1 }
$folder = [SvD]::Addr($d); "저장 폴더(임시): $folder"
if (-not (Test-Path -LiteralPath $folder)) { "ABORT: 폴더 경로를 못 읽음 — 창은 열어 둠"; exit 1 }
$t0 = Get-Date
$b = [SvD]::Btn($d, '저장(&S)'); [SvD]::SendMessage($b, 0x00F5, [IntPtr]0, [IntPtr]0) | Out-Null
$f = $null; for ($i = 0; $i -lt 30 -and -not $f; $i++) { Start-Sleep 1; $f = Get-ChildItem -LiteralPath $folder -File | Where-Object { $_.Name -like "*$Match*" -and $_.LastWriteTime -ge $t0.AddSeconds(-5) } | Select-Object -First 1 }
if (-not $f) { "ABORT: 저장된 파일을 못 찾음 ($folder)"; exit 1 }
Start-Sleep 2
Move-Item -LiteralPath $f.FullName -Destination $Dest -Force
$out = Join-Path $Dest $f.Name
"SAVED $out ($([math]::Round((Get-Item -LiteralPath $out).Length/1KB,1))KB) — 임시 폴더에는 남기지 않음"
