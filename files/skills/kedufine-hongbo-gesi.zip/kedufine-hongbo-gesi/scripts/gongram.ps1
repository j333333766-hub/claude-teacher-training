# 공람 지정: '공람' 탭 → 공람지정 → '공람그룹' 탭 → 그룹 체크 → 오른쪽으로 → 확인 → "결재경로에 있는 사용자는 제외" 확인.
#   pwsh -File gongram.ps1 -Hwnd <문서 창> [-Group "2026 ○○중 교원 전체"]
# 2026-10-18 ○○중학교-14699 로 확인(공람자 58명). 공람그룹은 교원 전체/교원_정/교원_기/부장단뿐이고 직원 그룹은 없다.
param([Parameter(Mandatory)][long]$Hwnd, [string]$Group = '2026 ○○중 교원 전체')
. "$PSScriptRoot\common.ps1"
Js $Hwnd "var as=document.getElementsByTagName('a'); for(var i=0;i<as.length;i++){ var t=(as[i].innerText||'').replace(/\s/g,''); if(/^공람\(\d+\)$/.test(t)){ as[i].click(); return t; } } return 'no tab';"
ClickBg $Hwnd @('-Id', 'btnCnrsAppn') 6
$D = NewDlg $Hwnd
if (-not $D) { 'ABORT: 공람 창이 안 뜸'; exit 1 }
"공람 창: $D"
ClickBg $D @('-Text', '공람그룹') 3
pwsh -NoProfile -File "$SAVE\iecheck.ps1" -Hwnd $D -Label $Group
Start-Sleep 1
pwsh -NoProfile -File "$SAVE\ieanchor.ps1" -Hwnd $D -Match 'btnRight' | Out-Null
Start-Sleep 2
ClickBg $D @('-Text', '확인') 5
$m = Msgs; $m
if ($m -match '제외되었습니다') { MsgOk '제외되었습니다' }
Start-Sleep 2
$n = Js $Hwnd "var as=document.getElementsByTagName('a'); for(var i=0;i<as.length;i++){ var t=(as[i].innerText||'').replace(/\s/g,''); if(/^공람\(\d+\)$/.test(t)) return t; } return '?';"
"DONE $n"
