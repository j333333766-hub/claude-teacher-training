# 처리하지 않고 공문 탭만 닫는다(건너뛸 공문, 열어만 본 공문). 공문 탭을 앞으로 가져온 뒤 fncClose() → "탭을 닫으" 예.
# 주의: id 'close' 링크를 누르면 안 닫힌다(onclick 이 안쪽 img 에 있음). 2026-10-18 확인.
#   pwsh -File closedoc.ps1 -Hwnd <문서 창> -Title "<탭 제목 일부>"
param([Parameter(Mandatory)][long]$Hwnd, [Parameter(Mandatory)][string]$Title)
. "$PSScriptRoot\common.ps1"
pwsh -NoProfile -File "$PSScriptRoot\tabfront.ps1" -Match $Title | Out-Null
Js $Hwnd "setTimeout(function(){ fncClose(); },200); return 'ok';" | Out-Null
for ($i = 0; $i -lt 10; $i++) {
  Start-Sleep 1
  $w = Wins
  if ($w -match '탭을 닫으') { pwsh -NoProfile -File "$SAVE\iemsg.ps1" -Must '탭을 닫으' -Button '예'; break }
}
Start-Sleep 1
if ((Wins) -match "^$Hwnd ") { 'STOP: 아직 열려 있음' ; exit 1 } else { 'DONE 닫음' }
