---
name: kedufine-hongbo-gesi
description: K-에듀파인 결재대기의 홍보 공문을 ○○중학교 홈페이지 공지사항에 게시하고, 그 공문을 교원 전체 공람 → 나의결재선 나(본인) → 과제카드 유관기관협조(교무) → 문서처리까지 끝내는 스킬. 여러 건이면 결재대기의 [홍보] 공문을 모두 차례로 처리한다. "홍보 공문 홈페이지에 올려줘", "공문 공지사항에 탑재해줘", "홍보 공문 처리해줘", "이 공문 홈페이지 게시하고 공람해줘", "결재대기 홍보 공문 다 올려줘"처럼 말하면 쓴다. 기안 작성(kedufine-gian)이나 공문 일괄 저장(kedufine-gongmun-jeojang)에는 쓰지 않는다.
---

# 홍보 공문 → 홈페이지 공지사항 게시 + 공람·문서처리

2026-10-18 ○○중학교-14699(공지사항 1453번)로 처음 끝까지 했고, 같은 날 자동화 부분(목록 읽기·상태 검증·글쓰기 스니펫·탭 닫기)을 따로 시험했다.

- 공문 창은 엣지 **IE 모드 탭** → 창 핸들의 문서 객체로 다룬다(스크립트가 `kedufine-gian`·`kedufine-gongmun-jeojang`의 검증된 스크립트를 부른다). 마우스·키보드는 쓰지 않는다.
- 에듀파인 목록·학교 홈페이지는 일반 탭 → Claude in Chrome.
- 스크립트: `~/.claude/skills/kedufine-hongbo-gesi/scripts/`, 모두 `pwsh -NoProfile -File …`.

## 진행 방식: 자동 모드와 확인 모드

- **자동 모드:** 요청에 "알아서", "끝까지", "등록·문서처리까지"가 들어 있으면 멈추지 않고 끝까지 간다. 그래도 아래 경우에는 반드시 멈추고 묻는다.
  - process.ps1 이 `STOP`을 내거나 예상과 다른 메시지 상자가 뜰 때
  - 개인정보 검출 알림, 로그인 만료
  - 행사가 이미 끝났는지 애매할 때, 홍보인지 애매한 공문
- **확인 모드(그 밖):** 공문 목록과 게시글 초안을 한 번에 보여 주고 허락을 받은 뒤 [등록]·[문서처리]를 한다. 여러 건이면 **한 번에 모아서** 묻는다(건마다 묻지 않는다).
- 인증서·홈페이지 로그인 암호는 대신 넣지 않는다. 끝난 행사는 게시글에서 뺀다(사용자 결정).

## 0. 브라우저 (Claude in Chrome)

- `list_connected_browsers` → 이름이 **「엣지 업무포털용」**인 것을 `select_browser`. 이름이 없으면 `switch_browser`로 사용자가 엣지에서 Connect를 누르게 한다.
- `tabs_context_mcp(createIfEmpty)` → 새 탭에서 작업한다. **탭 그룹의 마지막 탭을 닫으면 그룹이 사라지니** 작업이 다 끝날 때 닫는다.

## 1. 결재대기에서 [홍보] 공문 찾기 (좌표 대신 DOM)

1. `https://klef.ice.go.kr/keris_ui/main.do` → 공지 팝업이 있으면 [닫기](1081,224) → 왼쪽 결재(40,202) → 결재대기(62,230).
2. 목록은 iframe `…webWork_WebBrowser` 안의 HTML이다. 읽기:
   ```js
   const d=[...document.querySelectorAll('iframe')].find(f=>/webWork_WebBrowser/.test(f.id)).contentDocument;
   [...d.querySelectorAll('a')].filter(a=>a.closest('tr')&&/\[홍보\]/.test(a.innerText)).map((a,i)=>i+': '+a.innerText.trim()).join('\n')
   ```
   - 제목 링크의 onclick 은 `doCallClientApp(0,'<문서ID>',행,'')`이다. `a.click()`으로 연다.
   - 머리말이 없어도 홍보성인 공문(「…안내」, 외부기관 행사)은 사용자가 지목했을 때만 다룬다.
3. 연 뒤 핸들: `pwsh -File ~/.claude/skills/kedufine-gian/scripts/opencap.ps1 -Out shot.png` → `HWND=…`(맨 위 '4,' 로 시작하는 큰 문서 창).
   한 번에 한 건만 연다(문서 창이 여러 개면 핸들이 섞인다).

## 2. 본문·첨부 읽기 → 첨부 받기

```
pwsh -File scripts/tabfront.ps1 -Match "<제목 일부>"        # 뒤에 깔린 IE 탭은 캡처가 까맣고 저장 창이 안 뜬다
pwsh -File scripts/bodytext.ps1 -Hwnd <H> -Out body.txt      # 표·신청 링크·문의처까지 텍스트, 끝에 '첨부: …'
pwsh -File scripts/attsave.ps1 -Hwnd <H> -Match "<첨부 이름 일부>"   # 다운로드 폴더로 (SAVED …)
```
- attsave: PC저장 → '저장하기'(폴더 고르기)에서 지금 폴더에 저장 → 다운로드로 옮김. 임시 폴더에는 남지 않는다.
- `ABORT: 저장하기 창이 안 뜸` → tabfront 다시 → 한 번 더. 그래도 안 되면 사용자에게 저장을 부탁한다.

## 3. 홈페이지 공지사항 글쓰기

- 바로 `https://<우리학교>.icems.kr/boardCnts/Finsert.do?action=write&page=1&m=0201&s=kuwol` 로 간다(로그인 풀렸으면 사용자에게).
- 본문 쓰는 모양은 `references/homepage.md`. 채우기는 **`references/post.js` 한 번 실행**(첨부가 있으면 그 안의 STEP 0 → `find "임시 첨부 선택 file input"` → `file_upload` → post.js). 결과 `title=true / body set / files=1`.
- 스크린샷으로 확인 → (확인 모드면 허락) → 아래로 스크롤해 [등록] (등록 직전 `window.confirm=()=>true; window.alert=()=>{}` 로 확인 창을 막는다).
- 목록 맨 위 새 글을 열어 get_page_text 로 본문·「첨부파일」 확인 → **다운로드 폴더의 첨부 삭제**.

## 4. 공문 처리 — 한 번에

```
pwsh -File scripts/process.ps1 -Hwnd <H> -Title "<제목 일부>" -Process
```
- 공람(교원 전체) → 나의결재선 나(본인) → 과제카드 유관기관협조(교무)를 차례로 하고, 페이지 값을 읽어 **세 가지가 다 맞을 때만** 문서처리(procdoc)까지 한다. 끝나면 `DONE: 문서처리 완료`.
- 이미 된 단계는 건너뛰므로 멈춘 뒤 다시 돌려도 된다. `-CheckOnly` 는 읽기만 한다(아무것도 안 바꿈).
- `STOP` 이면 남은 캡처(`%TEMP%\kedufine_hongbo_check.png`)를 보고, 필요한 단계 스크립트만 따로 돌린다:
  `gongram.ps1 [-Group]`, `myroute.ps1 [-Option]`, `tkpick.ps1 [-Match | -List]`.
- 공람그룹은 교원 전체/교원_정/교원_기/부장단뿐(직원 그룹 없음). "전체 교직원"이면 교원 전체로 하고 보고 때 짚는다.
- 과제카드 "외부기관 협조" = `[교육행정서무관리] 유관기관협조(교무) (5년)`. 과제카드 돋보기는 결재선을 나(본인)로 바꾼 뒤에야 보인다.
- 처리하지 않고 닫을 공문: `pwsh -File scripts/closedoc.ps1 -Hwnd <H> -Title "<제목 일부>"` (id 'close' 를 누르면 안 닫힘 — fncClose() 사용).

## 5. 여러 건일 때

목록에서 [홍보] 공문을 모두 뽑아 → 건마다 1~4를 반복한다. 확인 모드면 처음에 「공문 n건 · 게시글 초안 n개」를 한꺼번에 보여 주고 한 번만 허락받는다. 한 건에서 STOP이 나면 그 건만 남기고 다음 건으로 넘어간 뒤 마지막에 모아 보고한다.

## 6. 보고

건마다: 게시글 번호·제목·첨부, 뺀 행사, 공람 수, 과제카드, 문서처리 결과. 마지막에 다운로드 첨부 삭제, 작업 탭 닫음.

## 바뀐 기록

- 2026-10-18: 처음 만듦(○○중학교-14699, 공지사항 1453번).
- 2026-10-18: 자동화 — 결재대기 목록 DOM 읽기·a.click() 열기, process.ps1(공람·결재선·과제카드 + 자동 검증 + 문서처리), post.js(제목·본문·첨부 한 번에), closedoc.ps1, 브라우저 이름 선택, 자동/확인 모드, 여러 건 처리. 목록 읽기·상태 읽기(-CheckOnly)·post.js 채우기·closedoc 은 실제 화면에서 시험함. 공람·결재선·과제카드를 process.ps1 로 한 번에 돌리는 것은 다음 홍보 공문이 첫 실행.
