// 홈페이지 공지사항 글쓰기 화면(Finsert.do)에서 한 번에: 제목·본문 채우기 + 첨부 끌어다 놓기.
// 쓰는 법: 아래 P 만 바꿔 javascript_tool 로 실행한다. 첨부가 있으면 먼저
//   (1) 이 파일 맨 아래 'STEP 0' 만 실행해 임시 input 을 만들고 → (2) find "임시 첨부 선택 file input" → file_upload →
//   (3) 이 파일 전체를 실행한다. 결과 문자열의 files=1 이면 첨부 성공.
// [등록]은 여기서 누르지 않는다(사용자 허락 뒤 따로).
const P = {
  title: '제목',
  paras: [                       // 문단마다 한 줄. 빈 줄은 ''. 링크는 <a href="…" target="_blank">…</a> 그대로 써도 됨
    '첫 문단',
    '',
    '가. …',
  ],
  fileName: '',                  // 올릴 때 쓸 첨부 이름(앞의 "기관명_" 접두어 뗀 것). 첨부 없으면 ''
};

const out = [];
const ti = document.getElementById('title');
ti.value = P.title; ti.dispatchEvent(new Event('input', { bubbles: true })); ti.dispatchEvent(new Event('change', { bubbles: true }));
out.push('title=' + (ti.value === P.title));
RAONKEDITOR.SetHtmlContents(P.paras.map(s => '<p>' + (s === '' ? '&nbsp;' : s) + '</p>').join(''), 'keditor');
out.push('body set');

const tmp = document.getElementById('cc_tmp_file');
if (P.fileName && tmp && tmp.files.length) {
  const f0 = tmp.files[0];
  const f = new File([f0], P.fileName, { type: f0.type || 'application/octet-stream', lastModified: Date.now() });
  const d = document.getElementById('raonkuploader_frame_kupload').contentDocument;
  const els = [...d.querySelectorAll('*')].filter(e => /드래그/.test(e.textContent || '') && e.children.length < 6);
  const t = els.length ? els[els.length - 1] : d.body;
  const dt = new DataTransfer(); dt.items.add(f);
  for (const n of ['dragenter', 'dragover', 'drop']) t.dispatchEvent(new DragEvent(n, { bubbles: true, cancelable: true, dataTransfer: dt }));
  await new Promise(r => setTimeout(r, 1500));
  tmp.remove();
}
out.push('files=' + RAONKUPLOAD.GetTotalFileCount('kupload'));
out.join(' / ');

/* STEP 0 (첨부가 있을 때 먼저 이것만 실행)
const i=document.createElement('input'); i.type='file'; i.id='cc_tmp_file'; i.setAttribute('aria-label','임시 첨부 선택');
i.style.cssText='position:fixed;top:10px;left:10px;z-index:99999'; document.body.appendChild(i); 'ok'
*/
