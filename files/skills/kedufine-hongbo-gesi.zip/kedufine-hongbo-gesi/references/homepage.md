# ○○중 홈페이지 공지사항 글쓰기 (Claude in Chrome, 엣지 「엣지 업무포털용」 브라우저)

2026-10-18 공지사항 1453번 「2026 꿈너머꿈 읽걷쓰 문예활동 지원 사업 안내」로 끝까지 확인했다.

## 주소
- 공지사항 목록: `https://<우리학교>.icems.kr/boardCnts/list.do?boardID=<공지사항 게시판 번호>&m=<메뉴>&s=<학교코드>` (쓰기권한 교직원)
- 목록 아래 [글쓰기] → `Finsert.do?action=write…`
- 로그인이 풀려 있으면 오른쪽 위에 이름 대신 로그인이 보인다 → 사용자에게 로그인을 부탁한다(암호는 대신 넣지 않는다).

## 본문 쓰는 모양 (기존 글들과 맞춤)
- 제목: 공문 제목에서 `[홍보]` 같은 머리말을 뗀다.
- 첫 문단: 공문 2항을 "…운영하오니, 관심 있는 학생, 교직원 및 학부모님의 많은 참여 바랍니다."처럼 홈페이지 말투로.
- 가. 나. 다. … 항목은 공문대로. 표는 항목별 줄로 풀어 쓴다(일시·장소·신청 링크).
- 신청 링크는 `<a href target=_blank>`로 건다.
- **오늘 이전에 끝난 행사·마감은 빼고 올린다**(사용자 결정 2026-10-18). 애매하면 물어본다.
- 공문의 "협조 요청 사항"(가정통신문·홈페이지 안내 부탁)과 기안자·결재자 줄은 넣지 않는다.
- 끝줄: `붙임 <첨부 이름> 1부.`

## 채우기 (javascript_tool)
```js
const ti=document.getElementById('title'); ti.value='<제목>';
ti.dispatchEvent(new Event('input',{bubbles:true})); ti.dispatchEvent(new Event('change',{bubbles:true}));
RAONKEDITOR.SetHtmlContents('<p>…</p><p>…</p>', 'keditor');   // 본문은 문단마다 <p>, 빈 줄은 <p>&nbsp;</p>
```
- `GetHtmlContents` 로 다시 읽으면 0이 나오지만 화면에는 들어가 있다. 스크린샷으로 확인한다.
- javascript_tool 결과에 함수 원문을 돌려주면 "[BLOCKED: Cookie/query string data]"로 막힌다. 짧은 값만 돌려준다.

## 첨부 올리기 (RAON K Upload, iframe `raonkuploader_frame_kupload`)
업로더 안의 file input 은 접근성 트리에 안 잡혀 file_upload 를 바로 못 쓴다. `RAONKUPLOAD.AddLocalFileObject`는 오류 없이 돌지만 실제로 안 붙는다. 확인된 방법:
1. 바깥 문서에 임시 file input 을 만든다.
   ```js
   const i=document.createElement('input'); i.type='file'; i.id='cc_tmp_file';
   i.setAttribute('aria-label','임시 첨부 선택'); i.style.cssText='position:fixed;top:10px;left:10px;z-index:99999';
   document.body.appendChild(i);
   ```
2. `find "임시 첨부 선택 file input"` → ref → `file_upload`(다운로드 폴더의 파일 경로).
3. 업로더의 "드래그하세요" 글자에 끌어다 놓기를 흉내 낸다. 이름 앞의 "인천광역시교육청 초등교육과_" 같은 접두어는 여기서 뗀다.
   ```js
   const f0=document.getElementById('cc_tmp_file').files[0];
   const f=new File([f0],'<올릴 파일 이름>.pdf',{type:f0.type,lastModified:Date.now()});
   const d=document.getElementById('raonkuploader_frame_kupload').contentDocument;
   const els=[...d.querySelectorAll('*')].filter(e=>/드래그/.test(e.textContent||'')&&e.children.length<6);
   const t=els[els.length-1]; const dt=new DataTransfer(); dt.items.add(f);
   for(const n of ['dragenter','dragover','drop']) t.dispatchEvent(new DragEvent(n,{bubbles:true,cancelable:true,dataTransfer:dt}));
   await new Promise(r=>setTimeout(r,1500)); RAONKUPLOAD.GetTotalFileCount('kupload')   // 1 이면 성공
   ```
4. `document.getElementById('cc_tmp_file').remove()`

## 등록 (사용자 확인 뒤에만)
- 화면을 아래로 내려 [임시저장][등록][취소] 중 **[등록]**을 누른다(find 로는 안 잡혀 좌표로 누름).
- 사이트가 확인 창을 띄울 수 있으므로 누르기 전에 막아 둔다: `window.confirm=m=>{(window.__msgs=window.__msgs||[]).push(m);return true}; window.alert=m=>{(window.__msgs=window.__msgs||[]).push(m)}`
- 등록되면 목록으로 돌아가 맨 위에 새 글이 보인다. 새 글을 열어 get_page_text 로 본문과 「첨부파일」 이름을 확인한다.
- 확인이 끝나면 다운로드 폴더의 임시 첨부를 지운다(사용자 지시).
