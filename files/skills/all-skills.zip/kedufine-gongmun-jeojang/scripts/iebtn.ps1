# IE 모드 탭 문서에서 지정한 id 요소들이 실제로 보이는지(크기·표시 여부) 확인. 읽기 전용.
param([long]$Hwnd, [string[]]$Ids)

Add-Type @'
using System; using System.Runtime.InteropServices;
public class IeDom {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  [DllImport("oleacc.dll", PreserveSig=false)] [return: MarshalAs(UnmanagedType.IDispatch)]
  public static extern object ObjectFromLresult(IntPtr lResult, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, IntPtr wParam);
  public static object Get(IntPtr h) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT");
    IntPtr res; SendMessageTimeout(h, msg, IntPtr.Zero, IntPtr.Zero, 2, 3000, out res);
    if (res == IntPtr.Zero) return null;
    return ObjectFromLresult(res, new Guid("626FC520-A41E-11CF-A731-00A0C9082637"), IntPtr.Zero);
  }
}
'@

$doc = [IeDom]::Get([IntPtr]$Hwnd)
if (-not $doc) { "문서 객체를 얻지 못함"; exit 1 }
foreach ($id in ($Ids -split ',')) {
  $e = $doc.getElementById($id)
  if (-not $e -or $e -is [DBNull]) { "$id : 없음"; continue }
  # 자신이나 조상 중 하나라도 display:none 이면 화면에 안 보인다
  $hidden = $false; $p = $e
  while ($p -and $p.tagName -ne 'BODY') { if ($p.currentStyle.display -eq 'none' -or $p.currentStyle.visibility -eq 'hidden') { $hidden = $true; break }; $p = $p.parentElement }
  "{0} : '{1}' 크기 {2}x{3} 숨김={4} onclick={5}" -f $id, ([string]$e.innerText).Trim(), $e.offsetWidth, $e.offsetHeight, $hidden, (([string]$e.getAttribute('onclick')) -replace '\s+',' ')
}
