# div 로만 그려진 화면(과제카드선택 등)에서 글자가 -Text 와 같은 가장 안쪽 요소를 찾는다.
#   구조 보기: pwsh -File iediv.ps1 -Hwnd 123 -Text "..." -Up 3      (부모 3단계 위의 outerHTML 출력)
#   누르기:    pwsh -File iediv.ps1 -Hwnd 123 -Text "..." -Click [-Up n] [-Tag input]
#              -Tag 를 주면 -Up 만큼 올라간 요소 안의 첫 번째 해당 태그를, 아니면 그 요소 자체를 누른다.
param([long]$Hwnd, [string]$Text, [int]$Up = 0, [switch]$Click, [string]$Tag, [string]$Scan = 'div')

Add-Type @'
using System; using System.Runtime.InteropServices;
public class IeDom {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  [DllImport("oleacc.dll", PreserveSig=false)] [return: MarshalAs(UnmanagedType.IDispatch)]
  public static extern object ObjectFromLresult(IntPtr lResult, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, IntPtr wParam);
  public static object Get(IntPtr h) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT");
    IntPtr res; SendMessageTimeout(h, msg, IntPtr.Zero, IntPtr.Zero, 2, 3000, out res);
    if (res == IntPtr.Zero) return null;
    return ObjectFromLresult(res, new Guid("626FC520-A41E-11CF-A731-00A0C9082637"), IntPtr.Zero);
  }
}
'@

$doc = [IeDom]::Get([IntPtr]$Hwnd)
if (-not $doc) { "문서 객체를 얻지 못함"; exit 1 }
$els = $doc.getElementsByTagName($Scan)
$hit = $null
# 같은 글자를 가진 요소가 겹겹이 있으므로 문서 순서상 마지막(가장 안쪽)을 고른다
for ($i = 0; $i -lt $els.length; $i++) {
  $e = $els.item($i)
  if ($e.offsetWidth -eq 0) { continue }
  if ((([string]$e.innerText) -replace '\s+', ' ').Trim() -eq $Text) { $hit = $e }
}
if (-not $hit) { "'$Text' 요소를 찾지 못함"; exit 2 }
$t = $hit; for ($k = 0; $k -lt $Up -and $t.parentElement; $k++) { $t = $t.parentElement }
if (-not $Click) { $h = ([string]$t.outerHTML) -replace '\s+', ' '; $h.Substring(0, [math]::Min(2500, $h.Length)); exit 0 }
if ($Tag) { $c = $t.getElementsByTagName($Tag); if ($c.length -eq 0) { "안에 $Tag 없음"; exit 3 }; $t = $c.item(0) }
foreach ($ev in 'onmousedown','onmouseup') { try { [void]$t.fireEvent($ev) } catch {} }
$t.click()
"누름: <$($t.tagName) id=$($t.id) class=$($t.className)>"
