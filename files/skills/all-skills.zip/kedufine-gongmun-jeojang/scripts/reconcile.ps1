# 저장 폴더를 점검한다: 본문 수, 문서번호 범위, 빠진 번호, 확장자별 개수·용량, 0바이트 파일.
#   pwsh -File reconcile.ps1 -Path "<저장 폴더>" [-Titles titles.txt] [-After 13906]
#   -Titles : '번호<TAB>발신기관<TAB>제목' 목록을 파일로 남긴다(홍보성 공문을 고를 때 읽는다. 발신기관이 빈 줄은 학교 내부 문서)
#   -After  : 이 번호보다 큰 문서만 센다(이어받기 때 이번에 새로 받은 것만 볼 때)
param([Parameter(Mandatory=$true)][string]$Path,[string]$Titles,[int]$After=0)
$f=Get-ChildItem -LiteralPath $Path -File | Where-Object { $_.Name -match '^\(.+?-(\d+) \((본문|첨부)\)' -and [int]$Matches[1] -gt $After }
$rows=foreach($x in $f){ if($x.Name -match '^\((.+?)-(\d+) \(본문\) ?(.*?)\) (.*)\.[^.]+$'){ [pscustomobject]@{N=[int]$Matches[2];Org=$Matches[1];S=$Matches[3];T=$Matches[4]} } }
$nums=@($rows.N | Sort-Object -Unique)
if(-not $nums.Count){ "본문 파일이 없습니다."; return }
"기관: " + (($rows.Org | Sort-Object -Unique) -join ', ')
"본문 $($nums.Count)건, 문서번호 $($nums[0])~$($nums[-1])"
$miss=@(($nums[0])..($nums[-1]) | Where-Object { $_ -notin $nums })
"범위 안에서 빠진 번호 $($miss.Count)개: " + ($miss -join ', ')
"파일 $($f.Count)개, {0:N2}GB, 0바이트 {1}개" -f (($f|Measure-Object Length -Sum).Sum/1GB), @($f|Where-Object Length -eq 0).Count
$f | Group-Object { $_.Extension.ToLower() } | ForEach-Object { [pscustomobject]@{확장자=$_.Name;개수=$_.Count;MB=[math]::Round(($_.Group|Measure-Object Length -Sum).Sum/1MB,1)} } | Sort-Object MB -Descending | Format-Table -AutoSize
if($Titles){ $rows | Sort-Object N -Descending | ForEach-Object { "$($_.N)`t$($_.S)`t$($_.T)" } | Set-Content -LiteralPath $Titles -Encoding utf8; "제목 목록: $Titles" }
