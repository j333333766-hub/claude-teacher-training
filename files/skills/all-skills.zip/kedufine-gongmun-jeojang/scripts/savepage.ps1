﻿# K-에듀파인 '파일저장' 탭(엣지 IE 모드)에서 한 페이지 분량을 저장하고 탭을 닫는다.
# 순서: 배포(PDF) 선택 -> 확인 -> 폴더 찾아보기 창에 저장 폴더 지정 -> 저장 완료 대기 -> 결과 팝업 닫기 -> 탭 닫기 '예'
# 사용: pwsh -File savepage.ps1 -path "D:\공문"  [-OkX 1878 -RadioX 553 -RadioDy 70]
#   OkX     : 초록 '확인' 버튼 가운데의 화면 X좌표
#   RadioX  : '배포(PDF 형식)' 글자 위의 화면 X좌표,  RadioDy : 확인 버튼에서 그 줄까지의 세로 거리(px)
#   좌표는 PC마다 다르므로 첫 페이지에서 화면을 캡처해 한 번 맞춘다(SKILL.md 4단계).
# 출력: 한 줄. 'DONE ...' 이면 성공, 'ABORT: ...' 이면 그 자리에서 멈춘 것(창은 그대로 둔다).
param([Parameter(Mandatory=$true)][string]$path,[int]$OkX=1878,[int]$RadioX=553,[int]$RadioDy=70,[int]$ScanTop=130,[int]$ScanHeight=150,[int]$StableSeconds=30)
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes, System.Drawing, System.Windows.Forms
Add-Type @"
using System;using System.Runtime.InteropServices;
public class W{
[DllImport("kernel32.dll")]public static extern IntPtr OpenProcess(uint a,bool b,int pid);
[DllImport("kernel32.dll")]public static extern IntPtr VirtualAllocEx(IntPtr h,IntPtr a,uint s,uint t,uint p);
[DllImport("kernel32.dll")]public static extern bool WriteProcessMemory(IntPtr h,IntPtr a,byte[] b,uint s,out UIntPtr w);
[DllImport("kernel32.dll")]public static extern bool VirtualFreeEx(IntPtr h,IntPtr a,uint s,uint t);
[DllImport("kernel32.dll")]public static extern bool CloseHandle(IntPtr h);
[DllImport("user32.dll")]public static extern IntPtr SendMessageW(IntPtr h,uint m,IntPtr w,IntPtr l);
[DllImport("user32.dll")]public static extern bool SetCursorPos(int x,int y);
[DllImport("user32.dll")]public static extern bool PostMessageW(IntPtr h,uint m,IntPtr w,IntPtr l);
[DllImport("user32.dll")]public static extern void mouse_event(uint f,uint dx,uint dy,uint d,UIntPtr e);}
"@
$A=[System.Windows.Automation.AutomationElement]; $TS=[System.Windows.Automation.TreeScope]
function Click($x,$y){ [W]::SetCursorPos($x,$y)|Out-Null; Start-Sleep -Milliseconds 200; [W]::mouse_event(2,0,0,0,[UIntPtr]::Zero); [W]::mouse_event(4,0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 800 }
function Grab($x,$y,$w,$h){ $b=New-Object System.Drawing.Bitmap $w,$h; $g=[System.Drawing.Graphics]::FromImage($b); $g.CopyFromScreen($x,$y,0,0,$b.Size); $g.Dispose(); $b }
function GreenY(){ $b=Grab $OkX $ScanTop 1 $ScanHeight; $ys=@(); for($y=0;$y -lt $ScanHeight;$y++){ $c=$b.GetPixel(0,$y); if($c.G -gt 90 -and $c.R -lt 110 -and $c.B -lt 80 -and ($c.G-$c.R) -gt 30){$ys+=$y} }; $b.Dispose(); if($ys.Count -lt 8){return -1}; return $ScanTop+[int](($ys|Measure-Object -Average).Average) }
function RadioOn($gy){ $b=Grab ($RadioX-5) ($gy+$RadioDy-5) 11 11; $on=$false; for($x=0;$x -lt 11;$x++){for($y=0;$y -lt 11;$y++){ $c=$b.GetPixel($x,$y); if($c.B -gt 170 -and $c.R -lt 90){$on=$true} }}; $b.Dispose(); $on }
function FindName($name,$sec){ for($i=0;$i -lt $sec*2;$i++){ $e=$A::RootElement.FindFirst($TS::Descendants,(New-Object System.Windows.Automation.PropertyCondition($A::NameProperty,$name))); if($e){return $e}; Start-Sleep -Milliseconds 500 }; $null }
function EdgeTitle(){ (Get-Process msedge -ErrorAction SilentlyContinue | Where-Object MainWindowTitle | Select-Object -First 1).MainWindowTitle }
function Bodies(){ Get-ChildItem -LiteralPath $path -File | ForEach-Object { if($_.Name -match '^\(.+?-(\d+) \(본문\)'){ [int]$Matches[1] } } | Sort-Object -Unique }

for($i=0;$i -lt 40 -and (EdgeTitle) -notlike '파일저장*';$i++){ Start-Sleep -Milliseconds 500 }
if((EdgeTitle) -notlike '파일저장*'){ "ABORT: 파일저장 탭이 안 열림 ("+(EdgeTitle)+")"; return }
Start-Sleep 2
$before=@(Bodies); $n0=(Get-ChildItem -LiteralPath $path -File).Count
$dlg=FindName '폴더 찾아보기' 1
if(-not $dlg){
$ok=$false
for($t=0;$t -lt 4 -and -not $ok;$t++){ $gy=GreenY; if($gy -lt 0){Start-Sleep 1; continue}; Click $RadioX ($gy+$RadioDy); $gy=GreenY; if($gy -ge 0){$ok=RadioOn $gy} }
if(-not $ok){ "ABORT: 배포(PDF) 선택 확인 실패 gy=$gy"; return }
for($t=0;$t -lt 3 -and -not $dlg;$t++){ $gy=GreenY; if(-not (RadioOn $gy)){ "ABORT: 라디오 풀림"; return }; Click $OkX $gy; $dlg=FindName '폴더 찾아보기' 6 }
}
if(-not $dlg){ "ABORT: 폴더 선택 창 안 뜸"; return }
$hwnd=[IntPtr]$dlg.Current.NativeWindowHandle; $procId=$dlg.Current.ProcessId
$bytes=[System.Text.Encoding]::Unicode.GetBytes($path+"`0")
$h=[W]::OpenProcess(0x0038,$false,$procId)
$mem=[W]::VirtualAllocEx($h,[IntPtr]::Zero,[uint32]$bytes.Length,0x3000,0x04)
$w=[UIntPtr]::Zero; $wr=[W]::WriteProcessMemory($h,$mem,$bytes,[uint32]$bytes.Length,[ref]$w)
[W]::SendMessageW($hwnd,0x467,[IntPtr]1,$mem) | Out-Null
Start-Sleep -Milliseconds 1500
[W]::VirtualFreeEx($h,$mem,0,0x8000) | Out-Null; [W]::CloseHandle($h) | Out-Null
if(-not $wr){ "ABORT: 경로 지정 실패(창 열린 채 둠)"; return }
$r=$dlg.Current.BoundingRectangle
$shot=Grab ([int]$r.X) ([int]$r.Y) ([int]$r.Width) ([int]$r.Height); $shot.Save((Join-Path $PSScriptRoot 'last_folder.png')); $shot.Dispose()
[W]::PostMessageW($hwnd,0x111,[IntPtr]1,[IntPtr]::Zero) | Out-Null
$prev=-1;$same=0;$started=$false
for($i=0;$i -lt 240;$i++){ Start-Sleep 5; $n=(Get-ChildItem -LiteralPath $path -File).Count; if($n -gt $n0){$started=$true}; if($n -eq $prev){$same++}else{$same=0}; $prev=$n; if($started -and $same -ge [math]::Ceiling($StableSeconds/5)){break}; if(-not $started -and $i -ge 18){ "ABORT: 90초간 새 파일 없음"; return } }
$after=@(Bodies); $new=@($after | Where-Object { $_ -notin $before })
$sd=FindName '문서저장 -- 웹 페이지 대화 상자' 3
if($sd){ $sr=$sd.Current.BoundingRectangle; $cx=[int]($sr.Right-30); $cy=[int]($sr.Top+48) } else { $cx=1223; $cy=407 }
$ie=$null; for($t=0;$t -lt 3 -and -not $ie;$t++){ Click $cx $cy; $ie=FindName 'Windows Internet Explorer' 3 }
if($ie){ $yb=$ie.FindFirst($TS::Descendants,(New-Object System.Windows.Automation.PropertyCondition($A::NameProperty,'예(Y)'))); if($yb){ $yr=$yb.Current.BoundingRectangle; Click ([int]($yr.X+$yr.Width/2)) ([int]($yr.Y+$yr.Height/2)) } }
Start-Sleep 1
$f=Get-ChildItem -LiteralPath $path -File
$miss=@(); if($new.Count){ $miss=@(($new[0])..($new[-1]) | Where-Object { $_ -notin $after }) }
"DONE new본문=$($new.Count) 범위=$($new[0])~$($new[-1]) 범위내누락=[$($miss -join ',')] 총파일=$($f.Count) 총본문=$($after.Count) {0:N0}MB zero={1} edge='{2}'" -f (($f|Measure-Object Length -Sum).Sum/1MB),@($f|Where-Object Length -eq 0).Count,(EdgeTitle)

