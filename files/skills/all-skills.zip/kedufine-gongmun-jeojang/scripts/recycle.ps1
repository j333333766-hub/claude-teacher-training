# 공문번호 단위(본문+첨부) 또는 확장자 단위로 파일을 휴지통에 보낸다. 완전 삭제가 아니라 되살릴 수 있다.
#   pwsh -File recycle.ps1 -Path "<저장 폴더>" -Numbers 13906,13901 [-ListOut 삭제목록.txt]
#   pwsh -File recycle.ps1 -Path "<저장 폴더>" -Extensions .zip,.7z,.mp3,.png,.jpg,.jpeg
#   -After : 이 문서번호보다 큰 파일만 대상으로 한다(이어받기 때 이전 회차 파일을 건드리지 않으려고)
#   pwsh -File recycle.ps1 -Path "<회차 폴더>" -UpTo 13906      (이어받기: 이미 받은 번호 이하를 걸러냄)
param([Parameter(Mandatory=$true)][string]$Path,[int[]]$Numbers,[string[]]$Extensions,[string]$ListOut,[int]$After=0,[int]$UpTo=0)
Add-Type -AssemblyName Microsoft.VisualBasic
$all=Get-ChildItem -LiteralPath $Path -File | Where-Object { $_.Name -match '^\(.+?-(\d+) \((본문|첨부)\)' -and [int]$Matches[1] -gt $After }
$t=@()
if($Numbers){ $t+=$all | Where-Object { $_.Name -match '^\(.+?-(\d+) \(' -and [int]$Matches[1] -in $Numbers } }
if($UpTo -gt 0){ $t+=$all | Where-Object { $_.Name -match '^\(.+?-(\d+) \(' -and [int]$Matches[1] -le $UpTo } }
if($Extensions){ $e=$Extensions | ForEach-Object { $_.ToLower() }; $t+=$all | Where-Object { $e -contains $_.Extension.ToLower() } }
$t=@($t | Sort-Object FullName -Unique)
if($ListOut -and $Numbers){ $t | Where-Object { $_.Name -match '\(본문\)' } | Sort-Object Name -Descending | ForEach-Object { $_.BaseName } | Set-Content -LiteralPath $ListOut -Encoding utf8 }
$mb=($t|Measure-Object Length -Sum).Sum/1MB; $fail=0
foreach($x in $t){ try{ [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($x.FullName,'OnlyErrorDialogs','SendToRecycleBin') }catch{ $fail++ } }
"휴지통으로 보낸 파일 {0}개, {1:N0}MB, 실패 {2}개" -f ($t.Count-$fail),$mb,$fail
