# IE 모드 탭(Internet Explorer_Server 창)에서 HTML 문서 객체를 얻어 읽는다. 읽기 전용.
# 트리(조직도)가 있는 창은 img 가 수백 개라 느리다. 그럴 땐 -Tags a,button 처럼 줄인다.
param([long]$Hwnd, [int]$MaxText = 3000, [string]$Tags = 'a,button,input,img')

Add-Type @'
using System; using System.Runtime.InteropServices;
public class IeDom {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  [DllImport("oleacc.dll", PreserveSig=false)] [return: MarshalAs(UnmanagedType.IDispatch)]
  public static extern object ObjectFromLresult(IntPtr lResult, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, IntPtr wParam);
  public static object Get(IntPtr h) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT");
    IntPtr res; SendMessageTimeout(h, msg, IntPtr.Zero, IntPtr.Zero, 2, 3000, out res);
    if (res == IntPtr.Zero) return null;
    return ObjectFromLresult(res, new Guid("626FC520-A41E-11CF-A731-00A0C9082637"), IntPtr.Zero);
  }
}
'@

function Dump-Doc($doc, $label) {
  "=== $label ==="
  "title : " + $doc.title
  "url   : " + $doc.URL
  "ready : " + $doc.readyState
  $txt = [string]$doc.body.innerText
  if ($txt.Length -gt $MaxText) { $txt = $txt.Substring(0, $MaxText) + ' …(생략)' }
  "--- text ---"; $txt
  "--- 누를 수 있는 것 ---"
  foreach ($tag in ($Tags -split ',')) {
    $els = $doc.getElementsByTagName($tag)
    for ($i = 0; $i -lt $els.length; $i++) {
      $e = $els.item($i)
      $t = ([string]$e.innerText).Trim(); if (-not $t) { $t = [string]$e.value }; if (-not $t) { $t = [string]$e.alt }; if (-not $t) { $t = [string]$e.title }
      if ($t -and $t.Length -lt 40) { "[$tag] id=$($e.id) name=$($e.name) type=$($e.type) :: $t" }
      elseif ($tag -ne 'img' -and $tag -ne 'input' -and $e.offsetWidth -gt 0) { "[$tag] id=$($e.id) class=$($e.className) (글자 없음) href=$([string]$e.getAttribute('href'))" }
    }
  }
  $fr = $doc.frames
  "--- frames: $($fr.length) ---"
  for ($i = 0; $i -lt $fr.length; $i++) {
    try { $fd = $fr.item($i).document; Dump-Doc $fd "$label / frame $i" } catch { "frame $i 접근 불가: $($_.Exception.Message)" }
  }
}

$doc = [IeDom]::Get([IntPtr]$Hwnd)
if (-not $doc) { "문서 객체를 얻지 못함"; exit 1 }
Dump-Doc $doc "hwnd $Hwnd"
