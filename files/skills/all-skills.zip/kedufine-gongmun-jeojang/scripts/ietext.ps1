# IE 모드 창에서 지정한 태그(기본 tr)의 보이는 요소 글자를 줄 단위로 읽는다. 표 내용 읽기용. 읽기 전용.
#   pwsh -File ietext.ps1 -Hwnd 123 [-Tag tr] [-Match "인사"]
param([long]$Hwnd, [string]$Tag = 'tr', [string]$Match)

Add-Type @'
using System; using System.Runtime.InteropServices;
public class IeDom {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  [DllImport("oleacc.dll", PreserveSig=false)] [return: MarshalAs(UnmanagedType.IDispatch)]
  public static extern object ObjectFromLresult(IntPtr lResult, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, IntPtr wParam);
  public static object Get(IntPtr h) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT");
    IntPtr res; SendMessageTimeout(h, msg, IntPtr.Zero, IntPtr.Zero, 2, 3000, out res);
    if (res == IntPtr.Zero) return null;
    return ObjectFromLresult(res, new Guid("626FC520-A41E-11CF-A731-00A0C9082637"), IntPtr.Zero);
  }
}
'@

$doc = [IeDom]::Get([IntPtr]$Hwnd)
if (-not $doc) { "문서 객체를 얻지 못함"; exit 1 }
$els = $doc.getElementsByTagName($Tag)
"$Tag $($els.length)개"
for ($i = 0; $i -lt $els.length; $i++) {
  $e = $els.item($i)
  if ($e.offsetWidth -eq 0) { continue }
  $t = (([string]$e.innerText) -replace '\s+', ' ').Trim()
  if (-not $t -or $t.Length -gt 300) { continue }
  if ($Match -and $t -notmatch $Match) { continue }
  "[$i] $t"
}
