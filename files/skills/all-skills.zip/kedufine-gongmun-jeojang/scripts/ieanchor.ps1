# IE 모드 창에서 글자 없는(아이콘만 있는) 보이는 링크를 나열하거나, 그중 innerHTML/onclick 에 -Match 문자열이 들어간 첫 번째를 누른다.
#   나열: pwsh -File ieanchor.ps1 -Hwnd 123
#   누름: pwsh -File ieanchor.ps1 -Hwnd 123 -Match "btn_add"
param([long]$Hwnd, [string]$Match)

Add-Type @'
using System; using System.Runtime.InteropServices;
public class IeDom {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  [DllImport("oleacc.dll", PreserveSig=false)] [return: MarshalAs(UnmanagedType.IDispatch)]
  public static extern object ObjectFromLresult(IntPtr lResult, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, IntPtr wParam);
  public static object Get(IntPtr h) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT");
    IntPtr res; SendMessageTimeout(h, msg, IntPtr.Zero, IntPtr.Zero, 2, 3000, out res);
    if (res == IntPtr.Zero) return null;
    return ObjectFromLresult(res, new Guid("626FC520-A41E-11CF-A731-00A0C9082637"), IntPtr.Zero);
  }
}
'@

$doc = [IeDom]::Get([IntPtr]$Hwnd)
if (-not $doc) { "문서 객체를 얻지 못함"; exit 1 }
$els = $doc.getElementsByTagName('a')
for ($i = 0; $i -lt $els.length; $i++) {
  $e = $els.item($i)
  if ($e.offsetWidth -eq 0 -or ([string]$e.innerText).Trim()) { continue }
  $html = (([string]$e.outerHTML) -replace '\s+', ' ')
  if ($Match) { if ($html -like "*$Match*") { $e.click(); "누름: [$i] " + $html.Substring(0, [math]::Min(200, $html.Length)); exit 0 } }
  else { "[$i] {0}x{1} :: {2}" -f $e.offsetWidth, $e.offsetHeight, $html.Substring(0, [math]::Min(300, $html.Length)) }
}
if ($Match) { "'$Match' 가 들어간 링크를 찾지 못함"; exit 2 }
