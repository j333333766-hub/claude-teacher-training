# IE 모드 창에서 옆 글자가 -Label 로 시작하는 체크박스를 찾아 누른다(트리의 그룹·사람 선택용).
# -List 를 주면 누르지 않고 보이는 체크박스의 옆 글자만 나열한다.
param([long]$Hwnd, [string]$Label, [switch]$List)

Add-Type @'
using System; using System.Runtime.InteropServices;
public class IeDom {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  [DllImport("oleacc.dll", PreserveSig=false)] [return: MarshalAs(UnmanagedType.IDispatch)]
  public static extern object ObjectFromLresult(IntPtr lResult, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, IntPtr wParam);
  public static object Get(IntPtr h) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT");
    IntPtr res; SendMessageTimeout(h, msg, IntPtr.Zero, IntPtr.Zero, 2, 3000, out res);
    if (res == IntPtr.Zero) return null;
    return ObjectFromLresult(res, new Guid("626FC520-A41E-11CF-A731-00A0C9082637"), IntPtr.Zero);
  }
}
'@

$doc = [IeDom]::Get([IntPtr]$Hwnd)
if (-not $doc) { "문서 객체를 얻지 못함"; exit 1 }
$els = $doc.getElementsByTagName('input')
"input $($els.length)개"
for ($i = 0; $i -lt $els.length; $i++) {
  $c = $els.item($i)
  if ($c.type -ne 'checkbox' -or $c.offsetWidth -eq 0) { continue }
  # 체크박스 옆 글자: 부모 요소의 글자에서 첫 줄만
  $t = (([string]$c.parentElement.innerText) -split "`n")[0].Trim()
  if ($List) { "[{0}] checked={1} id={2} :: {3}" -f $i, $c.checked, $c.id, $t; continue }
  if ($t.StartsWith($Label)) { $c.click(); "누름: '$t' → checked=$($c.checked)"; exit 0 }
}
if (-not $List) { "'$Label' 체크박스를 찾지 못함"; exit 2 }
