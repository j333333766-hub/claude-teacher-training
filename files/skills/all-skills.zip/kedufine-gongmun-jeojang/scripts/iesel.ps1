# IE 모드 창의 보이는 select(드롭다운)를 나열하거나, 지정한 것의 값을 바꾼다(change 이벤트도 발생시킴).
#   나열: pwsh -File iesel.ps1 -Hwnd 123
#   변경: pwsh -File iesel.ps1 -Hwnd 123 -Index 2 -Option "업무담당자"     (Index 는 나열에서 본 번호)
param([long]$Hwnd, [int]$Index = -1, [string]$Option)

Add-Type @'
using System; using System.Runtime.InteropServices;
public class IeDom {
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern uint RegisterWindowMessage(string s);
  [DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr h, uint msg, IntPtr w, IntPtr l, uint flags, uint timeout, out IntPtr result);
  [DllImport("oleacc.dll", PreserveSig=false)] [return: MarshalAs(UnmanagedType.IDispatch)]
  public static extern object ObjectFromLresult(IntPtr lResult, [MarshalAs(UnmanagedType.LPStruct)] Guid riid, IntPtr wParam);
  public static object Get(IntPtr h) {
    uint msg = RegisterWindowMessage("WM_HTML_GETOBJECT");
    IntPtr res; SendMessageTimeout(h, msg, IntPtr.Zero, IntPtr.Zero, 2, 3000, out res);
    if (res == IntPtr.Zero) return null;
    return ObjectFromLresult(res, new Guid("626FC520-A41E-11CF-A731-00A0C9082637"), IntPtr.Zero);
  }
}
'@

$doc = [IeDom]::Get([IntPtr]$Hwnd)
if (-not $doc) { "문서 객체를 얻지 못함"; exit 1 }
$els = $doc.getElementsByTagName('select')
for ($i = 0; $i -lt $els.length; $i++) {
  $s = $els.item($i)
  if ($s.offsetWidth -eq 0) { continue }
  $opts = @(); for ($k = 0; $k -lt $s.options.length; $k++) { $o = $s.options.item($k); $opts += ("{0}{1}={2}" -f $(if ($k -eq $s.selectedIndex) { '*' } else { '' }), $o.value, ([string]$o.text).Trim()) }
  if ($Index -lt 0) { "[{0}] id={1} name={2} onchange={3} :: {4}" -f $i, $s.id, $s.name, ((([string]$s.getAttribute('onchange')) -replace '\s+',' ')), ($opts -join ' | '); continue }
  if ($i -ne $Index) { continue }
  for ($k = 0; $k -lt $s.options.length; $k++) {
    if (([string]$s.options.item($k).text).Trim() -eq $Option) { $s.selectedIndex = $k; [void]$s.fireEvent('onchange'); "변경: [$i] → '$Option'"; exit 0 }
  }
  "[$i] 에 '$Option' 항목이 없음: $($opts -join ' | ')"; exit 2
}
