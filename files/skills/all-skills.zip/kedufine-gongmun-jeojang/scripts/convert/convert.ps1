# 폴더 안의 한글·워드·엑셀·파워포인트 파일을 PDF로 바꾼다(같은 폴더에 생성). 한글의 '접근 허용' 창은 뜨지 않는다.
#   pwsh -File convert.ps1 -Path "<저장 폴더>" [-RecycleOriginals] [-After 13906]
#   -RecycleOriginals : 변환에 성공한 원본만 휴지통으로 보낸다(실패한 원본은 남는다)
#   -After            : 이 문서번호보다 큰 파일만 변환한다(이어받기)
# 반드시 PowerShell 7(pwsh)로 실행한다. Windows PowerShell 5.1에서는 워드 변환이 멈추는 PC가 있다.
# 암호 걸린 문서, 확장자만 바뀐 파일은 실패로 남는 것이 정상이다.
# 진행 상황은 %TEMP%\kedufine_convert\progress.txt (UTF-16)에 '순번|ok/err/wait|내용'으로 쌓인다.
param([Parameter(Mandatory=$true)][string]$Path,[switch]$RecycleOriginals,[int]$After=0)
$work=Join-Path $env:TEMP 'kedufine_convert'
New-Item -ItemType Directory -Force $work | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'worker.ps1'),(Join-Path $PSScriptRoot 'FilePathCheckerModule.dll') $work -Force
foreach($old in 'progress.txt','cancel.flag'){ $o=Join-Path $work $old; if(Test-Path -LiteralPath $o){ [IO.File]::Delete($o) } }
$ext='.hwp','.hwpx','.doc','.docx','.docm','.odt','.xls','.xlsx','.xlsm','.ppt','.pptx','.pptm','.ppsx'
$files=@(Get-ChildItem -LiteralPath $Path -File | Where-Object { $ext -contains $_.Extension.ToLower() } | Where-Object { $After -le 0 -or ($_.Name -match '^\(.+?-(\d+) \(' -and [int]$Matches[1] -gt $After) } | Sort-Object Name)
if(-not $files.Count){ "변환할 파일이 없습니다."; return }
"변환 대상 $($files.Count)개. 진행 상황: $work\progress.txt"
$flag='0'; if($RecycleOriginals){ $flag='1' }
Set-Content -LiteralPath (Join-Path $work 'job.txt') -Value (@('topdf','same','',$flag) + $files.FullName) -Encoding Unicode
& pwsh -NoProfile -ExecutionPolicy Bypass -File (Join-Path $work 'worker.ps1') (Join-Path $work 'job.txt')
$pr=Get-Content -LiteralPath (Join-Path $work 'progress.txt') -Encoding Unicode
"성공 $(@($pr -match '^\d+\|ok\|').Count), 실패 $(@($pr -match '^\d+\|err\|').Count), 완료표시 $($pr -contains '__DONE__')"
foreach($l in $pr){ if($l -match '^(\d+)\|err\|(.*)$'){ "실패: " + $files[[int]$Matches[1]].Name + "  ->  " + $Matches[2] } }
