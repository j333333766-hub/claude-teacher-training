﻿param([string]$JobPath)
$ErrorActionPreference = 'Stop'
$dir     = Split-Path -Parent $JobPath
$prog    = Join-Path $dir 'progress.txt'
$cancel  = Join-Path $dir 'cancel.flag'
$pidFile = Join-Path $dir 'worker.pid'
$state = @()
$stage = ''

Set-Content -LiteralPath $pidFile -Value ('' + $PID) -Encoding Unicode
try { Add-Type -AssemblyName System.IO.Compression.FileSystem } catch { }

$shCode = @'
using System;
using System.Runtime.InteropServices;
public class HwpRecycle {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct SHFILEOPSTRUCT {
        public IntPtr hwnd;
        public uint wFunc;
        [MarshalAs(UnmanagedType.LPWStr)] public string pFrom;
        [MarshalAs(UnmanagedType.LPWStr)] public string pTo;
        public ushort fFlags;
        public bool fAnyOperationsAborted;
        public IntPtr hNameMappings;
        [MarshalAs(UnmanagedType.LPWStr)] public string lpszProgressTitle;
    }
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern int SHFileOperation(ref SHFILEOPSTRUCT op);
    public static int ToRecycleBin(string path) {
        SHFILEOPSTRUCT op = new SHFILEOPSTRUCT();
        op.wFunc = 3;
        op.pFrom = path + "\0\0";
        op.fFlags = 0x0454;
        return SHFileOperation(ref op);
    }
}
'@

function Flush-State {
    param([string[]]$Extra)
    $all = @($state)
    if ($stage) { $all = $all + ('__STAGE__|' + $stage) }
    if ($Extra) { $all = $all + $Extra }
    for ($t = 0; $t -lt 5; $t++) {
        try { Set-Content -LiteralPath $prog -Value $all -Encoding Unicode; return }
        catch { Start-Sleep -Milliseconds 120 }
    }
}

# 확장자 → (엔진, 파일 시그니처 종류)
#   엔진: HWP(한글) / XL(엑셀) / PP(파워포인트)
#   시그니처: HWP(OLE 또는 HWP 텍스트 헤더) / OLE(구형 오피스) / ZIP(OOXML·HWPX)
function Get-FileKind {
    param([string]$Ext)
    switch ($Ext) {
        '.hwp'  { return @('HWP', 'HWP') }
        '.hwpx' { return @('HWP', 'ZIP') }
        '.doc'  { return @('WD',  'OLE') }
        '.docx' { return @('WD',  'ZIP') }
        '.docm' { return @('WD',  'ZIP') }
        '.odt'  { return @('WD',  'ZIP') }
        '.xls'  { return @('XL',  'OLE') }
        '.xlsx' { return @('XL',  'ZIP') }
        '.xlsm' { return @('XL',  'ZIP') }
        '.ppt'  { return @('PP',  'OLE') }
        '.pptx' { return @('PP',  'ZIP') }
        '.pptm' { return @('PP',  'ZIP') }
        '.ppsx' { return @('PP',  'ZIP') }
    }
    return $null
}

function Test-SourceSignature {
    param([string]$Path, [string]$Kind)
    $buf = New-Object byte[] 32
    $n = 0
    $fs = [IO.File]::OpenRead($Path)
    try { $n = $fs.Read($buf, 0, 32) } finally { $fs.Close() }
    if ($n -lt 8) { return 'bad' }
    $isZip = ($buf[0] -eq 0x50 -and $buf[1] -eq 0x4B -and $buf[2] -eq 0x03 -and $buf[3] -eq 0x04)
    $ole = @(0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1)
    $isOle = $true
    for ($j = 0; $j -lt 8; $j++) { if ($buf[$j] -ne $ole[$j]) { $isOle = $false; break } }
    if ($Kind -eq 'ZIP') {
        if ($isZip) { return 'ok' }
        # 암호를 건 xlsx/pptx는 ZIP이 아니라 OLE 컨테이너에 암호화되어 저장된다
        if ($isOle) { return 'encrypted' }
        return 'bad'
    }
    if ($Kind -eq 'OLE') {
        if ($isOle) { return 'ok' }
        # 확장자만 .doc/.xls/.ppt인 RTF·HTML·XML 파일은 업무 시스템이 자주 내보내는 형식이라 오피스가 열 수 있다 → 시도
        $head = [Text.Encoding]::ASCII.GetString($buf, 0, $n).TrimStart([char]0xEF, [char]0xBB, [char]0xBF, ' ', "`t", "`r", "`n").ToLower()
        if ($head.StartsWith('{\rtf') -or $head.StartsWith('<html') -or $head.StartsWith('<!doctype') -or $head.StartsWith('<?xml')) { return 'ok' }
        # UTF-16 BOM(FF FE)으로 시작하는 HTML/XML 텍스트도 허용
        if ($buf[0] -eq 0xFF -and $buf[1] -eq 0xFE) { return 'ok' }
        return 'bad'
    }
    if ($isOle) { return 'ok' }
    $txt = [Text.Encoding]::ASCII.GetString($buf, 0, $n)
    if ($txt.StartsWith('HWP Document File')) { return 'ok' }
    return 'bad'
}

function Test-ResultFile {
    param([string]$Path, [string]$Fmt)
    if (-not (Test-Path -LiteralPath $Path)) { return '결과 파일이 생성되지 않았습니다' }
    if ((Get-Item -LiteralPath $Path).Length -le 0) { return '결과 파일이 비어 있습니다' }
    if ($Fmt -eq 'HWPX') {
        try {
            $names = @()
            $z = [IO.Compression.ZipFile]::OpenRead($Path)
            try { $names = @($z.Entries | ForEach-Object { $_.FullName }) } finally { $z.Dispose() }
            if (($names -notcontains 'mimetype') -and ($names -notcontains 'Contents/section0.xml')) {
                return '결과 HWPX 내용이 올바르지 않습니다'
            }
        } catch { return '결과 HWPX를 열 수 없습니다' }
    } else {
        $b = New-Object byte[] 4
        $fs = [IO.File]::OpenRead($Path)
        try { $null = $fs.Read($b, 0, 4) } finally { $fs.Close() }
        if ([Text.Encoding]::ASCII.GetString($b, 0, 4) -ne '%PDF') { return '결과 PDF가 올바르지 않습니다' }
    }
    return ''
}

# ── 변환 엔진(한글·엑셀·파워포인트)은 실제로 필요한 순간에 하나씩 띄운다 ──
$script:hwp = $null
$script:hwpOwned = $true
$script:wd  = $null
$script:xl  = $null
$script:pp  = $null
$script:ppOwned = $false          # 파워포인트를 우리가 새로 띄웠는지 (이미 떠 있던 창을 닫지 않기 위해)
$script:ppPid = 0
$script:ownedPids = @()            # 우리가 새로 띄운 엔진 프로세스 PID (앱이 강제 중지할 때 정리용)
$enginesFile = Join-Path $dir 'engines.txt'

function Get-NewPids {
    param([string]$Name, [int[]]$Before)
    return @(Get-Process -Name $Name -ErrorAction SilentlyContinue | Where-Object { $Before -notcontains $_.Id } | Select-Object -ExpandProperty Id)
}
function Save-Engines {
    param([string]$Name, [int[]]$Before)
    $new = Get-NewPids $Name $Before
    if ($new.Count -gt 0) {
        $script:ownedPids += $new
        try { Set-Content -LiteralPath $enginesFile -Value ($script:ownedPids | ForEach-Object { '' + $_ }) -Encoding Unicode } catch { }
    }
    return $new
}
$script:engineErr = @{}           # 한 번 실행에 실패한 엔진은 다시 시도하지 않음
$script:engineName = @{ HWP = '한글'; WD = '워드'; XL = '엑셀'; PP = '파워포인트' }

function Get-Engine {
    param([string]$Kind)
    if ($script:engineErr.ContainsKey($Kind)) { throw $script:engineErr[$Kind] }
    if ($Kind -eq 'HWP' -and $script:hwp) { return $script:hwp }
    if ($Kind -eq 'WD'  -and $script:wd)  { return $script:wd }
    if ($Kind -eq 'XL'  -and $script:xl)  { return $script:xl }
    if ($Kind -eq 'PP'  -and $script:pp)  { return $script:pp }

    $prevStage = $script:stage
    $script:stage = ($script:engineName[$Kind] + '을(를) 실행하는 중입니다…')
    Flush-State
    try {
        if ($Kind -eq 'HWP') {
            # 파일 접근 승인 대화상자를 끄는 모듈(FilePathCheckerModule.dll)을 HKCU에 등록
            try {
                $dll = Join-Path $dir 'FilePathCheckerModule.dll'
                if (Test-Path -LiteralPath $dll) {
                    $key = 'HKCU:\Software\HNC\HwpAutomation\Modules'
                    if (-not (Test-Path $key)) { $null = New-Item -Path $key -Force }
                    Set-ItemProperty -Path $key -Name 'AutomationModule' -Value $dll
                }
            } catch { }
            $b = @(Get-Process -Name Hwp -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)
            $h = New-Object -ComObject HWPFrame.HwpObject
            $script:hwpOwned = ((Save-Engines 'Hwp' $b).Count -gt 0)   # 이미 떠 있던 한글에 붙었으면 Quit하지 않음
            $null = $h.RegisterModule('FilePathCheckDLL', 'AutomationModule')
            $script:hwp = $h
            $script:stage = $prevStage; Flush-State
            return $h
        }
        if ($Kind -eq 'WD') {
            $b = @(Get-Process -Name WINWORD -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)
            $w = New-Object -ComObject Word.Application
            $null = Save-Engines 'WINWORD' $b
            $w.Visible = $false
            try { $w.DisplayAlerts = 0 } catch { }           # wdAlertsNone
            try { $w.AutomationSecurity = 3 } catch { }
            $script:wd = $w
            $script:stage = $prevStage; Flush-State
            return $w
        }
        if ($Kind -eq 'XL') {
            $b = @(Get-Process -Name EXCEL -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)
            $x = New-Object -ComObject Excel.Application
            $null = Save-Engines 'EXCEL' $b
            $x.Visible = $false
            $x.DisplayAlerts = $false
            try { $x.AutomationSecurity = 3 } catch { }     # 매크로 실행 안 함
            try { $x.AskToUpdateLinks = $false } catch { }
            try { $x.EnableEvents = $false } catch { }
            $script:xl = $x
            $script:stage = $prevStage; Flush-State
            return $x
        }
        if ($Kind -eq 'PP') {
            $b = @(Get-Process -Name POWERPNT -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)
            $p = New-Object -ComObject PowerPoint.Application
            $newPp = Save-Engines 'POWERPNT' $b
            $script:ppOwned = ($newPp.Count -gt 0)
            if ($script:ppOwned) { $script:ppPid = $newPp[0] }
            try { $p.DisplayAlerts = 1 } catch { }          # ppAlertsNone
            try { $p.AutomationSecurity = 3 } catch { }
            $script:pp = $p
            $script:stage = $prevStage; Flush-State
            return $p
        }
        throw ('알 수 없는 엔진: ' + $Kind)
    } catch {
        $script:engineErr[$Kind] = ($script:engineName[$Kind] + '을(를) 실행할 수 없습니다: ' + $_.Exception.Message)
        throw $script:engineErr[$Kind]
    }
}

function Convert-WithHwp {
    param([string]$Src, [string]$SrcFmt, [string]$Dest, [string]$SaveFmt)
    $h = Get-Engine 'HWP'
    $ok = $h.Open($Src, '', 'forceopen:true')
    if (-not $ok) { $ok = $h.Open($Src, $SrcFmt, 'forceopen:true') }
    if (-not $ok) { throw '파일을 열 수 없습니다 (손상되었거나 암호가 걸린 문서)' }
    try {
        $saved = $h.SaveAs($Dest, $SaveFmt, '')
    } finally {
        try { $null = $h.XHwpDocuments.Close($true) } catch { }
    }
    if (-not $saved) { throw '저장에 실패했습니다' }
}

function Convert-WithWord {
    param([string]$Src, [string]$Dest)
    $w = Get-Engine 'WD'
    $doc = $null
    try {
        # ConfirmConversions=false, ReadOnly=true, AddToRecentFiles=false, 가짜 암호로 입력창 방지
        try {
            $doc = $w.Documents.Open($Src, $false, $true, $false, 'hwpconv-nopass')
        } catch {
            $m = $_.Exception.Message
            if ($m -match '암호|password') { throw '암호가 걸린 문서는 변환할 수 없습니다 (암호를 해제한 뒤 다시 시도하세요)' }
            throw ('파일을 열 수 없습니다: ' + ($m -replace '\s+', ' ').Trim())
        }
        if (-not $doc) {
            try {
                $pv = $w.ProtectedViewWindows
                if ($pv.Count -gt 0) { $doc = $pv.Item($pv.Count).Edit() }
            } catch { }
        }
        if (-not $doc) { throw '파일을 열 수 없습니다 (손상되었거나 암호가 걸린 문서)' }
        try { $doc.ExportAsFixedFormat($Dest, 17) }         # 17 = wdExportFormatPDF
        catch { throw ('PDF 저장에 실패했습니다: ' + (($_.Exception.Message -replace '\s+', ' ').Trim())) }
    } finally {
        if ($doc) { try { $doc.Close(0) } catch { } }        # 0 = wdDoNotSaveChanges
    }
}

function Convert-WithExcel {
    param([string]$Src, [string]$Dest)
    $x = Get-Engine 'XL'
    $wb = $null
    try {
        # ReadOnly=true, 링크 갱신 안 함, 암호 문서는 가짜 암호를 넘겨 입력창이 뜨지 않게 함
        try {
            $wb = $x.Workbooks.Open($Src, 0, $true, [Type]::Missing, 'hwpconv-nopass')
        } catch {
            $m = $_.Exception.Message
            if ($m -match '암호|password') { throw '암호가 걸린 문서는 변환할 수 없습니다 (암호를 해제한 뒤 다시 시도하세요)' }
            throw ('파일을 열 수 없습니다: ' + ($m -replace '\s+', ' ').Trim())
        }
        # 인터넷에서 받은 파일이 '제한된 보기'로 열린 경우 편집 모드로 전환
        if (-not $wb) {
            try {
                $pv = $x.ProtectedViewWindows
                if ($pv.Count -gt 0) { $wb = $pv.Item($pv.Count).Edit() }
            } catch { }
        }
        if (-not $wb) { throw '파일을 열 수 없습니다 (손상되었거나 암호가 걸린 문서)' }
        try { $wb.ExportAsFixedFormat(0, $Dest) }         # 0 = xlTypePDF, 모든 시트
        catch {
            $m = ($_.Exception.Message -replace '\s+', ' ').Trim()
            if ($wb.Worksheets.Count -gt 0 -and $m -match '저장|save|인쇄|print') {
                throw '인쇄할 내용이 없어 PDF를 만들 수 없습니다 (빈 통합 문서)'
            }
            throw ('PDF 저장에 실패했습니다: ' + $m)
        }
    } finally {
        if ($wb) { try { $wb.Close($false) } catch { } }
    }
}

function Convert-WithPowerPoint {
    param([string]$Src, [string]$Dest)
    $p = Get-Engine 'PP'
    $pres = $null
    try {
        # ReadOnly, Untitled=false, WithWindow=false(창 띄우지 않음)
        # 파일명 뒤 '::암호::'는 파워포인트의 암호 지정 문법 — 가짜 암호를 넘겨 암호 입력창이 뜨지 않게 함
        try {
            $pres = $p.Presentations.Open(($Src + '::hwpconv-nopass::'), $true, $false, $false)
        } catch {
            $m = $_.Exception.Message
            if ($m -match '암호|password') { throw '암호가 걸린 문서는 변환할 수 없습니다 (암호를 해제한 뒤 다시 시도하세요)' }
            throw ('파일을 열 수 없습니다: ' + ($m -replace '\s+', ' ').Trim())
        }
        if (-not $pres) {
            try {
                $pv = $p.ProtectedViewWindows
                if ($pv.Count -gt 0) { $pres = $pv.Item($pv.Count).Edit() }
            } catch { }
        }
        if (-not $pres) { throw '파일을 열 수 없습니다 (손상되었거나 암호가 걸린 문서)' }
        if ($pres.Slides.Count -le 0) { throw '슬라이드가 없어 PDF를 만들 수 없습니다' }
        try { $pres.SaveAs($Dest, 32) }                    # 32 = ppSaveAsPDF
        catch { throw ('PDF 저장에 실패했습니다: ' + (($_.Exception.Message -replace '\s+', ' ').Trim())) }
    } finally {
        if ($pres) { try { $pres.Close() } catch { } }
    }
}

function Close-Engines {
    if ($script:hwp) {
        $script:stage = '한글을 정리하는 중입니다…'; Flush-State
        if ($script:hwpOwned) { try { $script:hwp.Quit() } catch { } }
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:hwp) } catch { }
        $script:hwp = $null
    }
    if ($script:wd) {
        $script:stage = '워드를 정리하는 중입니다…'; Flush-State
        try {
            if ($script:wd.Documents.Count -gt 0) { $script:wd.Visible = $true }
            else { $script:wd.Quit(0) }
        } catch { }
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:wd) } catch { }
        $script:wd = $null
    }
    if ($script:xl) {
        $script:stage = '엑셀을 정리하는 중입니다…'; Flush-State
        try {
            # 변환 중 사용자가 연 통합 문서가 이 인스턴스에 붙었다면 닫지 말고 보여준다
            if ($script:xl.Workbooks.Count -gt 0) { $script:xl.Visible = $true }
            else { $script:xl.Quit() }
        } catch { }
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:xl) } catch { }
        $script:xl = $null
    }
    if ($script:pp) {
        $script:stage = '파워포인트를 정리하는 중입니다…'; Flush-State
        $quitPp = $false
        try {
            if ($script:ppOwned -and $script:pp.Presentations.Count -eq 0) { $script:pp.Quit(); $quitPp = $true }
        } catch { }
        try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($script:pp) } catch { }
        $script:pp = $null
        [GC]::Collect(); [GC]::WaitForPendingFinalizers()
        # Quit 뒤에도 우리가 띄운 파워포인트 프로세스가 창 없이 남아 있으면 정리
        if ($quitPp -and $script:ppPid) {
            Start-Sleep -Seconds 3
            try {
                $zp = Get-Process -Id $script:ppPid -ErrorAction SilentlyContinue
                if ($zp -and $zp.MainWindowTitle -eq '') { Stop-Process -Id $script:ppPid -Force -ErrorAction SilentlyContinue }
            } catch { }
        }
    }
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
    try { Remove-Item -LiteralPath $enginesFile -Force -ErrorAction SilentlyContinue } catch { }
}

$lines   = @(Get-Content -LiteralPath $JobPath -Encoding Unicode)
$mode    = $lines[0]
$outMode = $lines[1]
$outDir  = $lines[2]
$delSrc  = ($lines[3] -eq '1')
$files   = @()
if ($lines.Count -gt 4) {
    $files = @($lines[4..($lines.Count - 1)] | Where-Object { $_.Trim() -ne '' })
}

$canRecycle = $false
if ($delSrc) {
    try { Add-Type -TypeDefinition $shCode -ErrorAction Stop; $canRecycle = $true } catch { $canRecycle = $false }
}

for ($i = 0; $i -lt $files.Count; $i++) { $state += ('' + $i + '|wait|') }
$stage = '변환을 준비하는 중입니다…'
Flush-State

if ($mode -eq 'hwp2hwpx') { $saveFmt = 'HWPX'; $targetExt = '.hwpx' }
else                      { $saveFmt = 'PDF';  $targetExt = '.pdf'  }

$firstHwp = $true
for ($i = 0; $i -lt $files.Count; $i++) {
    if (Test-Path -LiteralPath $cancel) {
        for ($k = $i; $k -lt $files.Count; $k++) { $state[$k] = ('' + $k + '|err|사용자가 중지함') }
        break
    }
    $src = $files[$i]
    $state[$i] = ('' + $i + '|run|')
    $ext  = [IO.Path]::GetExtension($src).ToLower()
    $kind = Get-FileKind $ext
    $stage = ('변환 중 (' + ($i + 1) + '/' + $files.Count + ') ' + [IO.Path]::GetFileName($src))
    if ($kind -and $kind[0] -eq 'HWP' -and $firstHwp -and -not $script:hwp) {
        $stage = $stage + '  ·  첫 한글 파일은 한글 준비 때문에 시간이 더 걸릴 수 있습니다'
    }
    Flush-State
    try {
        if (-not (Test-Path -LiteralPath $src)) { throw '원본 파일을 찾을 수 없습니다' }
        if (-not $kind) { throw '지원하지 않는 파일 형식입니다' }
        if ($mode -eq 'hwp2hwpx' -and $ext -ne '.hwp') { throw 'HWP 파일만 HWPX로 변환할 수 있습니다' }
        $engine = $kind[0]; $sig = $kind[1]
        $sigResult = Test-SourceSignature $src $sig
        if ($sigResult -eq 'encrypted') { throw '암호가 걸린 문서는 변환할 수 없습니다 (암호를 해제한 뒤 다시 시도하세요)' }
        if ($sigResult -ne 'ok') {
            throw ($script:engineName[$engine] + ' 문서 형식이 아닙니다 (확장자만 바뀐 파일이거나 손상된 문서)')
        }

        if ($outMode -eq 'same') { $destDir = Split-Path -Parent $src } else { $destDir = $outDir }
        if (-not (Test-Path -LiteralPath $destDir)) {
            $null = New-Item -ItemType Directory -Path $destDir -Force
        }
        $base = [IO.Path]::GetFileNameWithoutExtension($src)
        $dest = Join-Path $destDir ($base + $targetExt)
        $n = 1
        while (Test-Path -LiteralPath $dest) {
            $dest = Join-Path $destDir ($base + ' (' + $n + ')' + $targetExt)
            $n++
        }

        if ($engine -eq 'HWP') {
            if ($ext -eq '.hwpx') { $srcFmt = 'HWPX' } else { $srcFmt = 'HWP' }
            Convert-WithHwp $src $srcFmt $dest $saveFmt
            $firstHwp = $false
        }
        elseif ($engine -eq 'WD') { Convert-WithWord $src $dest }
        elseif ($engine -eq 'XL') { Convert-WithExcel $src $dest }
        else                      { Convert-WithPowerPoint $src $dest }

        $bad = Test-ResultFile $dest $saveFmt
        if ($bad -ne '') {
            try { Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue } catch { }
            throw $bad
        }

        $note = ''
        if ($delSrc) {
            if (-not $canRecycle) { $note = '|원본 삭제 실패 (휴지통 기능을 쓸 수 없음)' }
            else {
                $rc = 1
                for ($try = 0; $try -lt 3; $try++) {
                    $rc = [HwpRecycle]::ToRecycleBin($src)
                    if ($rc -eq 0) { break }
                    Start-Sleep -Milliseconds 400
                }
                if ($rc -eq 0) { $note = '|원본 휴지통으로' }
                else           { $note = '|원본 삭제 실패 (코드 ' + $rc + ')' }
            }
        }
        $state[$i] = ('' + $i + '|ok|' + $dest + $note)
    } catch {
        $msg = ($_.Exception.Message -replace '[\r\n\|]', ' ')
        $state[$i] = ('' + $i + '|err|' + $msg)
    }
    Flush-State
}

Close-Engines
$stage = ''
Flush-State @('__DONE__')
