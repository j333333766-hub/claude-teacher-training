# 사용자가 직접 연 나이스 탭(확장 탭 그룹 밖)의 공지 팝업을 UI Automation으로 닫는다.
# 사용법: pwsh -File close-popup.ps1 [-Option 일주일|오늘]
param([string]$Option = '일주일')
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes
$AE=[System.Windows.Automation.AutomationElement]; $CT=[System.Windows.Automation.ControlType]
function Cond($p,$v){ New-Object System.Windows.Automation.PropertyCondition($p,$v) }
function And($a,$b){ New-Object System.Windows.Automation.AndCondition($a,$b) }
$wins = $AE::RootElement.FindAll('Children',(Cond $AE::ClassNameProperty 'Chrome_WidgetWin_1')) |
  ? { $_.Current.Name -match '나이스' -and $_.Current.Name -match 'Edge' }
if(-not $wins){ "NO_NEIS_WINDOW"; exit 1 }
$closed=0
foreach($w in $wins){
  while($true){
    $dlgs = $w.FindAll('Descendants',(Cond $AE::ControlTypeProperty $CT::Window))
    $dlg = $dlgs | select -First 1
    if(-not $dlg){ break }
    $name = $dlg.Current.Name
    $cb = $dlg.FindFirst('Descendants',(And (Cond $AE::NameProperty "$Option 창 열지 않음") (Cond $AE::ControlTypeProperty $CT::CheckBox)))
    if($cb){ $tp=$cb.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern); if($tp.Current.ToggleState -ne 'On'){ $tp.Toggle() } }
    $btn = $dlg.FindAll('Descendants',(And (Cond $AE::NameProperty '닫기') (Cond $AE::ControlTypeProperty $CT::Button))) |
      sort { $_.Current.BoundingRectangle.Y } | select -Last 1
    if(-not $btn){ "NO_CLOSE_BUTTON: $name"; break }
    $btn.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
    "CLOSED: $name"; $closed++
    Start-Sleep -Milliseconds 800
    if($closed -ge 10){ break }
  }
}
if($closed -eq 0){ "NO_POPUP" }
