// K-에듀파인 메인 탭(https://klef.ice.go.kr/keris_ui/main.do)에서 javascript_tool 로 한 번 실행해 도우미를 심는다.
// 그 뒤로는 짧게 부른다:  await EF.open('결재대기')   EF.list()   EF.keepAlive(20)   EF.status()
// (주의) javascript_tool 결과에 '='·'&' 가 많은 문자열(주소·쿠키 비슷한 것)이나 함수 원문을 돌려주면 "[BLOCKED: Cookie/query string data]" 로 막힌다. 짧은 값만 돌려줄 것.
window.EF = (() => {
  const app = () => nexacro.getApplication();
  const fs = () => app().mainframe.MainVFrameSet;
  const top = () => fs().TopFrame.form;
  const work = () => fs().SubHFrameSet.WorkVFrameSet.WorkFrame;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  // 알림·확인 창이 브라우저를 멈추지 않게 막고 내용을 남긴다(확인 창은 '취소'로 답함 → 실수로 진행되지 않음)
  window.__efMsgs = window.__efMsgs || [];
  window.alert = (m) => { window.__efMsgs.push(String(m).slice(0, 120)); };
  window.confirm = (m) => { window.__efMsgs.push('확인창(취소함): ' + String(m).slice(0, 120)); return false; };

  // 메뉴 이름(또는 menuId)으로 화면을 연다. 메뉴 ID 는 gdsMenu.menuId (progrmId 와 다르다)
  async function open(name) {
    const ds = app().gdsMenu;
    let r = ds.findRow('menuNm', name);
    if (r < 0) r = ds.findRow('menuId', name);
    if (r < 0) return '메뉴 없음: ' + name;
    const id = ds.getColumn(r, 'menuId');
    top().gfnOpenMenu(id);
    for (let i = 0; i < 16; i++) { await sleep(500); if (frameOf(id)) break; }
    await sleep(1500);
    return frameOf(id) ? '열림 ' + name + ' (' + id + ')' : '안 열림 ' + name;
  }
  function frameOf(id) { const w = work(); for (let i = 0; i < w.frames.length; i++) if (w.frames[i].name.indexOf(id) >= 0) return w.frames[i]; return null; }
  function close(name) { const ds = app().gdsMenu; const r = ds.findRow('menuNm', name); if (r >= 0) top().gfnCloseMenu(ds.getColumn(r, 'menuId')); return 'closed ' + name; }

  // 지금 앞에 있는 HTML 목록 화면(결재대기·문서등록대장 등)의 문서
  function doc() {
    const f = [...document.querySelectorAll('iframe')].filter((x) => /webWork_WebBrowser/.test(x.id) && x.offsetWidth > 0);
    return f.length ? f[f.length - 1].contentDocument : null;
  }
  // 목록의 제목들(행 번호·제목). 여는 것은 EF.openRow(i) — 제목 링크(onclick doCallClientApp)를 누른다.
  function list(filter) {
    const d = doc(); if (!d) return '목록 화면 아님';
    const as = [...d.querySelectorAll('a')].filter((a) => a.closest('tr') && (a.getAttribute('onclick') || '').indexOf('doCallClientApp') >= 0);
    window.__efRows = as;
    return as.map((a, i) => i + ': ' + a.innerText.trim()).filter((s) => !filter || s.indexOf(filter) >= 0).join('\n');
  }
  function openRow(i) { const a = (window.__efRows || [])[i]; if (!a) return '행 없음'; a.click(); return '열기: ' + a.innerText.trim().slice(0, 40); }

  // 자동 로그아웃(60분) 막기: 오른쪽 위 남은 시간 옆 [연장]을 누른다. 기본 20분마다.
  function extend() { const g = top().divTopGrp.form; g.btnUseTimeExtn.click(); return g.staUseTime.text; }
  function keepAlive(min = 20) {
    clearInterval(window.__efKA);
    window.__efKA = setInterval(() => { try { window.__efKAlast = new Date().toLocaleTimeString() + ' ' + extend(); } catch (e) { window.__efKAlast = 'ERR ' + e.message; } }, min * 60000);
    window.__efKAlast = new Date().toLocaleTimeString() + ' ' + extend();
    return '로그인 유지 켬(' + min + '분마다): ' + window.__efKAlast;
  }
  function status() {
    let t = '?'; try { t = top().divTopGrp.form.staUseTime.text; } catch (e) { t = '읽기 실패(로그아웃?)'; }
    return '남은 시간 ' + t + ' / 유지 ' + (window.__efKA ? '켜짐, 마지막 ' + window.__efKAlast : '꺼짐') + ' / 알림 ' + window.__efMsgs.slice(-3).join(' | ');
  }
  return { open, close, list, openRow, doc, extend, keepAlive, status };
})();
'EF ready';
